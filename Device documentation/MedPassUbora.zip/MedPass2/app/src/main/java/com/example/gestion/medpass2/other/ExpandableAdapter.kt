package com.example.gestion.medpass2.other

import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.activities.MainActivity

/*
I used this answer to code this adapter
https://stackoverflow.com/questions/34841320/android-studio-adding-switch-to-child-group-of-expandablelistview/34841550#34841550
 */


class ExpandableAdapter(
    var context: Context,
    var expandableListView: ExpandableListView,
    var header: Array<String>,
    var body: List<Array<String>>
) : BaseExpandableListAdapter() {

    override fun getGroup(groupPosition: Int): String {
        return header[groupPosition]
    }

    override fun isChildSelectable(groupPosition: Int, childPosition: Int): Boolean {
        return true
    }

    override fun hasStableIds(): Boolean {
        return false
    }

    override fun getGroupView(groupPosition: Int, isExpanded: Boolean, convertView: View?, parent: ViewGroup?): View {
        var convertView = convertView
        if (convertView == null) {
            val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.layout_group, null)
        }
        val planta = convertView?.findViewById<TextView>(R.id.System)
        planta?.text = getGroup(groupPosition)
        planta?.setOnClickListener {
            if (expandableListView.isGroupExpanded(groupPosition)) {
                expandableListView.collapseGroup(groupPosition)
            } else {
                expandableListView.expandGroup(groupPosition)

            }
        }

        return convertView!!
    }

    override fun getChildrenCount(groupPosition: Int): Int {
        return body[groupPosition].size
    }

    override fun getChild(groupPosition: Int, childPosition: Int): String {
        return body[groupPosition][childPosition]
    }

    override fun getGroupId(groupPosition: Int): Long {
        return groupPosition.toLong()
    }

    override fun getChildView(
        groupPosition: Int,
        childPosition: Int,
        isLastChild: Boolean,
        convertView: View?,
        parent: ViewGroup?
    ): View {
        var convertView = convertView
        val childName = getChild(groupPosition, childPosition)
        var childHolder: ChildHolder? =
            ChildHolder()
        if (convertView == null) {
            val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.layout_child, null)
            childHolder?.textChild = convertView!!.findViewById<View>(R.id.questions) as TextView
            childHolder?.switchChild = convertView!!.findViewById<View>(R.id.switchAnswer) as Switch
            convertView.setTag(childHolder)
        } else {

            childHolder = convertView.getTag() as ChildHolder
        }
        restoreSwitchState(childHolder?.switchChild!!, childName)
        childHolder?.textChild?.text = childName
        //on click, disease saved into prefs
        childHolder?.switchChild?.setOnClickListener {
            val prefs = context.getSharedPreferences("ANSWERS", 0)
            val editor = prefs.edit()
            if (childHolder!!.switchChild!!.isChecked) {
                checkAlreadyAdded(childName, prefs, editor)
            } else {
                editor.remove(childName)
                editor.putBoolean(childName, false)
                editor.apply()
            }
        }

        return convertView!!

    }

    override fun getChildId(groupPosition: Int, childPosition: Int): Long {
        return childPosition.toLong()
    }

    override fun getGroupCount(): Int {
        return header.size
    }

    //to be able to access each element textView and switch
    class ChildHolder() {

        var textChild: TextView? = null
        var switchChild: Switch? = null

    }

    //to retrieve saved state of switch and check corresponding switch
    fun restoreSwitchState(switch: Switch, childName: String) {
        val prefs = context.getSharedPreferences("ANSWERS", 0)
        val state = prefs.getBoolean(childName, false)
        switch.isChecked = state


    }

    //check if disease already added into prefs. It it is added, remove and then add it again
    fun checkAlreadyAdded(childName: String, prefs: SharedPreferences, editor: SharedPreferences.Editor) {
        if (prefs.contains(childName)) {
            editor.remove(childName).apply()
        }
        val mainActivity = context as MainActivity
        var patient = mainActivity.retrievePatient()
        editor.putBoolean(childName, true)
        editor.apply()


    }


}




