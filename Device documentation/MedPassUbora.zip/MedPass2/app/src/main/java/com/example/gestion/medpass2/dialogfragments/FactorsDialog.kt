package com.example.gestion.medpass2.dialogfragments

import android.content.Context
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.Toast
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import com.example.gestion.medpass2.activities.MainActivity
import java.util.*

class FactorsDialog : DialogFragment() {
    var mainActivity: MainActivity? = null
    var patient: Patient? = null
    var translatePatient: Patient? = null
    var factors: MutableList<String> = ArrayList()
    var language: String = ""
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity
        //retrieve saved patient. Info in key language
        patient = mainActivity!!.retrievePatient()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val vista = inflater.inflate(R.layout.factors_dialog, container, false)
        val saveFactors = vista.findViewById<View>(R.id.save_factors)
        val pacemaker = vista.findViewById<CheckBox>(R.id.pacemaker_check)
        val cardioverter = vista.findViewById<CheckBox>(R.id.cardioverter_check)
        val checkButtons = listOf(pacemaker, cardioverter)
        language = Locale.getDefault().language
        //translate patient's info into language
        translatePatient = Translation(context, patient).translateToLanguage(language)
        //Display factors saved
        setSavedFactors(translatePatient, checkButtons)
        //save selected factors into translated patient and then translate it again to key before saving into shared prefs
        saveFactors.setOnClickListener {
            if (patient == null) {
                patient = Patient()
            }
            for (item in checkButtons) {
                if (item.isChecked) {
                    factors.add(item.text.toString())
                }
            }
            translatePatient = translatePatient!!.copy(factors = this.factors)//esta en el idioma
            patient = Translation(context, translatePatient).translateToKey(language)//para pasarlo a clave
            mainActivity!!.savePatient(patient)
            Toast.makeText(context, getString(R.string.successful_save), Toast.LENGTH_LONG).show()
            dialog.dismiss()

        }

        return vista
    }

    // display checkboxes of factors inside patient checked
    fun setSavedFactors(patient: Patient?, checkButtons: List<CheckBox>) {
        if (patient != null) {
            val factors = patient.factors
            if (!factors!!.isEmpty()) {
                for (item in factors) {
                    when (item) {
                        getString(R.string.cardiacPacemaker) -> checkButtons[0].isChecked = true
                        getString(R.string.cardioverter) -> checkButtons[1].isChecked = true
                    }
                }


            }

        }

    }













}