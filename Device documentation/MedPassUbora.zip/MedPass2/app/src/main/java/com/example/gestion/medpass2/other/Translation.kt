package com.example.gestion.medpass2.other

import android.content.Context
import android.util.Log
import com.example.gestion.medpass2.activities.MainActivity

class Translation(val context: Context?, var patient: Patient?) {
    val activity = context as MainActivity


    //translates patient's info from device language to key
    fun translateToKey(language: String): Patient? {
        if (patient == null) {
            return null
        } else {
            //translate nationality and health insurance which are different and at the moment do not operate on databases
            val nationalities = activity.nationalityList
            var nationality = patient!!.nationality
            if (nationality != null && nationality.isNotEmpty() && nationalities != null) {
                for (item in nationalities) {
                    if (item.component1().equals(nationality)) {
                        nationality = item.component2()
                        break
                    }
                }
            }
            patient = patient?.copy(nationality = nationality)

            val healthInsuranceList = activity.healthInsuranceList
            var healthInsurance = patient?.insurance
            if (healthInsurance != null && healthInsurance.isNotEmpty() && healthInsuranceList != null) {
                for (item in healthInsuranceList) {
                    if (item.component1().equals(healthInsurance)) {
                        healthInsurance = item.component2()
                        break
                    }
                }
                patient = patient?.copy(insurance = healthInsurance)

            }

            val pathologies = patient!!.pathologies
            val drugsAllergies = patient!!.drugsAllergies
            val foodAllergies = patient!!.foodAllergies
            val otherAllergies = patient!!.otherAllergies
            val chronicMedication = patient?.chronicMedication
            val lastMedication = patient?.lastMedication
            val factors = patient?.factors
            val newpat: MutableList<String> = ArrayList()
            val newfood: MutableList<String> = ArrayList()
            val newdrugsA: MutableList<String> = ArrayList()
            val newother: MutableList<String> = ArrayList()
            val newchronic: MutableList<String> = ArrayList()
            val newlast: MutableList<String> = ArrayList()
            val newFactors: MutableList<String> = ArrayList()
            activity.conditionsDB?.installDataBaseIfNotExists()
            activity.medicationDatabase?.installDataBaseIfNotExists()
            val conditionsDB = activity.conditionsDB!!.openDatabase()
            val medicationDB = activity.medicationDatabase!!.openDatabase()
            var columnName = "Nombre_en"//default
            var columnNameDrugs = "drug_en"

            if (language == "es") {
                columnName = "Nombre_es"
                columnNameDrugs = "drug_es"
            }
            if (drugsAllergies == null || drugsAllergies.isEmpty()) {
            } else {
                for (i in 0 until drugsAllergies.size) {
                    var sqlQuery =
                        "SELECT drugKey FROM drugs WHERE $columnNameDrugs= '${drugsAllergies[i]}'"
                    var cursor = medicationDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newdrugsA.add(cursor.getString(cursor.getColumnIndex("drugKey")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(drugsAllergies = newdrugsA)

            }
            if (foodAllergies == null || foodAllergies.isEmpty()) {
            } else {
                for (i in 0 until foodAllergies.size) {
                    var sqlQuery =
                        "SELECT TranslateKey FROM informacion_medica WHERE $columnName= '${foodAllergies[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newfood.add(cursor.getString(cursor.getColumnIndex("TranslateKey")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(foodAllergies = newfood)
            }
            if (otherAllergies == null || otherAllergies.isEmpty()) {
            } else {
                for (i in 0 until otherAllergies.size) {
                    var sqlQuery =
                        "SELECT TranslateKey FROM informacion_medica WHERE $columnName= '${otherAllergies[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newother.add(cursor.getString(cursor.getColumnIndex("TranslateKey")))
                        cursor.close()
                    }

                }
                patient = patient!!.copy(otherAllergies = newother)
            }
            if (pathologies == null || pathologies.isEmpty()) {
            } else {
                for (i in 0 until pathologies.size) {
                    var sqlQuery = "SELECT TranslateKey FROM informacion_medica WHERE $columnName= '${pathologies[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newpat.add(cursor.getString(cursor.getColumnIndex("TranslateKey")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(pathologies = newpat)
            }
            if (factors == null || factors.isEmpty()) {
            } else {
                for (i in 0 until factors.size) {
                    var sqlQuery = "SELECT TranslateKey FROM informacion_medica WHERE $columnName= '${factors[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newFactors.add(cursor.getString(cursor.getColumnIndex("TranslateKey")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(factors = newFactors)
                conditionsDB.close()
            }
            if (chronicMedication == null || chronicMedication.isEmpty()) {
            } else {
                for (i in 0 until chronicMedication.size) {
                    var sqlQuery = "SELECT drugKey FROM drugs WHERE $columnNameDrugs= '${chronicMedication[i]}'"
                    var cursor = medicationDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newchronic.add(cursor.getString(cursor.getColumnIndex("drugKey")))
                        cursor.close()
                    }
                }
                patient = patient?.copy(chronicMedication = newchronic)
            }
            if (lastMedication == null || lastMedication.isEmpty()) {
            } else {
                for (i in 0 until lastMedication.size) {
                    var sqlQuery = "SELECT drugKey FROM drugs WHERE $columnNameDrugs= '${lastMedication[i]}'"
                    var cursor = medicationDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newlast.add(cursor.getString(cursor.getColumnIndex("drugKey")))
                        cursor.close()
                    }
                }
                patient = patient?.copy(lastMedication = newlast)
                medicationDB.close()
            }

            return patient

        }


    }

    //translate patient's info from key to device language

    fun translateToLanguage(language: String): Patient? {
        if (patient == null) {
            return null
        } else {
            //translate nationality and health insurance which are different and at the moment do not operate on databases
            val nationalities = activity.nationalityList
            var nationality = patient!!.nationality
            if (nationality != null && nationality.isNotEmpty() && nationalities != null) {
                for (item in nationalities) {
                    if (item.component2().equals(nationality)) {
                        nationality = item.component1()
                        break
                    }

                }
                patient = patient?.copy(nationality = nationality)
            }


            val healthInsuranceList = activity.healthInsuranceList
            var healthInsurance = patient?.insurance
            if (healthInsurance != null && healthInsurance.isNotEmpty() && healthInsuranceList != null) {
                for (item in healthInsuranceList) {
                    if (item.component2().equals(healthInsurance)) {
                        healthInsurance = item.component1()
                        break
                    }
                }
                patient = patient?.copy(insurance = healthInsurance)

            }
            val pathologies = patient!!.pathologies //key
            val drugsAllergies = patient!!.drugsAllergies
            val foodAllergies = patient!!.foodAllergies
            val otherAllergies = patient!!.otherAllergies
            val chronicMedication = patient?.chronicMedication
            val lastMedication = patient?.lastMedication
            val factors = patient?.factors
            val newpat: MutableList<String> = ArrayList() //language
            val newfood: MutableList<String> = ArrayList()
            val newother: MutableList<String> = ArrayList()
            val newchronic: MutableList<String> = ArrayList()
            val newlast: MutableList<String> = ArrayList()
            val newdrugsA: MutableList<String> = ArrayList()
            val newFactors: MutableList<String> = ArrayList()
            activity.conditionsDB!!.installDataBaseIfNotExists()
            val medicationDB = activity.medicationDatabase!!.openDatabase()
            val conditionsDB = activity.conditionsDB!!.openDatabase()
            var columnName = "Nombre_en"
            var columnNameDrugs = "drug_en"
            if (language == "es") {
                columnName = "Nombre_es"
                columnNameDrugs = "drug_es"
            }
            if (drugsAllergies == null || drugsAllergies.isEmpty()) {
            } else {
                for (i in 0 until drugsAllergies.size) {
                    var sqlQuery =
                        "SELECT $columnNameDrugs FROM drugs WHERE drugKey= '${drugsAllergies[i]}'"
                    var cursor = medicationDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newdrugsA.add(cursor.getString(cursor.getColumnIndex("$columnNameDrugs")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(drugsAllergies = newdrugsA)

            }
            if (foodAllergies == null || foodAllergies.isEmpty()) {
            } else {
                for (i in 0 until foodAllergies.size) {
                    var sqlQuery =
                        "SELECT $columnName FROM informacion_medica WHERE TranslateKey= '${foodAllergies[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newfood.add(cursor.getString(cursor.getColumnIndex("$columnName")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(foodAllergies = newfood)
            }
            if (otherAllergies == null || otherAllergies.isEmpty()) {
            } else {
                for (i in 0 until otherAllergies.size) {
                    var sqlQuery =
                        "SELECT $columnName FROM informacion_medica WHERE TranslateKey= '${otherAllergies[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newother.add(cursor.getString(cursor.getColumnIndex("$columnName")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(otherAllergies = newother)
            }
            if (pathologies == null || pathologies.isEmpty()) {
            } else {
                for (i in 0 until pathologies.size) {
                    var sqlQuery = "SELECT $columnName FROM informacion_medica WHERE TranslateKey= '${pathologies[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newpat.add(cursor.getString(cursor.getColumnIndex("$columnName")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(pathologies = newpat)

            }
            if (factors == null || factors.isEmpty()) {
            } else {
                for (i in 0 until factors.size) {
                    var sqlQuery = "SELECT $columnName FROM informacion_medica WHERE TranslateKey= '${factors[i]}'"
                    var cursor = conditionsDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newFactors.add(cursor.getString(cursor.getColumnIndex("$columnName")))
                        cursor.close()
                    }
                }
                patient = patient!!.copy(factors = newFactors)
                conditionsDB.close()
            }

            if (chronicMedication == null || chronicMedication.isEmpty()) {
            } else {
                for (i in 0 until chronicMedication.size) {
                    var sqlQuery = "SELECT $columnNameDrugs FROM drugs WHERE drugKey= '${chronicMedication[i]}'"
                    var cursor = medicationDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newchronic.add(cursor.getString(cursor.getColumnIndex("$columnNameDrugs")))
                        cursor.close()
                    }
                }
                patient = patient?.copy(chronicMedication = newchronic)
            }
            if (lastMedication == null || lastMedication.isEmpty()) {
            } else {
                for (i in 0 until lastMedication.size) {
                    var sqlQuery = "SELECT $columnNameDrugs FROM drugs WHERE drugKey= '${lastMedication[i]}'"
                    var cursor = medicationDB.rawQuery(sqlQuery, null)
                    var boolean = cursor!!.moveToFirst()
                    if (cursor.count > 0) {
                        newlast.add(cursor.getString(cursor.getColumnIndex("$columnNameDrugs")))
                        cursor.close()
                    }
                }
                patient = patient?.copy(lastMedication = newlast)
                medicationDB.close()
            }
            return patient
        }
    }

    fun translateAnswersKey(item: String, language: String): String {
        var translate = ""
        activity.conditionsDB!!.installDataBaseIfNotExists()
        val conditionsDB = activity.conditionsDB!!.openDatabase()
        var columnName = "Nombre_en"
        if (language == "es") {
            columnName = "Nombre_es"
        }
        var sqlQuery = "SELECT TranslateKey FROM informacion_medica WHERE $columnName= '$item'"
        var cursor = conditionsDB.rawQuery(sqlQuery, null)
        var boolean = cursor!!.moveToFirst()
        translate = cursor.getString(cursor.getColumnIndex("TranslateKey"))
        cursor.close()
        conditionsDB.close()
        return translate

    }

    fun translateAnswersLanguage(item: String, language: String): String {
        var translate = ""
        activity.conditionsDB!!.installDataBaseIfNotExists()
        val conditionsDB = activity.conditionsDB!!.openDatabase()
        var columnName = "Nombre_en"
        if (language == "es") {
            columnName = "Nombre_es"
        }
        var sqlQuery = "SELECT $columnName FROM informacion_medica WHERE TranslateKey = '$item'"
        var cursor = conditionsDB.rawQuery(sqlQuery, null)
        var boolean = cursor!!.moveToFirst()
        translate = cursor.getString(cursor.getColumnIndex("$columnName"))
        cursor.close()
        conditionsDB.close()
        return translate

    }


}