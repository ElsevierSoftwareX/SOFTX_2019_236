package com.example.gestion.medpass2.databases

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.io.FileOutputStream
import java.lang.RuntimeException

open class conditionsDB(context: Context) : SQLiteOpenHelper(
    context,
    DB_NAME, null,
    DB_VERSION
) {
    val context = context
    override fun onCreate(db: SQLiteDatabase?) {

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }

    companion object {
        const val DB_NAME = "conditions.sqlite3"
        const val DB_VERSION = 1

    }
    /*
   This method checks if database is already copied and if it is not,
   it copies it from assets.
    */

    fun installDataBaseIfNotExists() {
        val inputStream = context.assets.open(DB_NAME)
        try {
            val outputFile = File(context.getDatabasePath(DB_NAME).path)
            if (!outputFile.exists()) {
                val outPutStream = FileOutputStream(outputFile)

                inputStream.copyTo(outPutStream)
                inputStream.close()
                outPutStream.flush()
                outPutStream.close()
            }
        } catch (exception: Throwable) {
            throw RuntimeException("couldn't install database")
        }

    }

    fun openDatabase(): SQLiteDatabase {
        return SQLiteDatabase.openDatabase(context.getDatabasePath(DB_NAME).path, null, 0)
    }

    /*
    /*
    This fun is used to make queries to database in order to get disease items that match what the user entered in the search field
     */
     */
    fun userSuggestions(searchTerm: String, language: String): MutableList<String> {
        val suggestionsList: MutableList<String> = ArrayList()
        var columnName: String? = "Nombre_en" //default value

        when (language) {
            "es" -> {
                //le digo que la columna es la de spanish
                columnName = "Nombre_es"
            }
            "en" -> {
                columnName = "Nombre_en"
            }
        }
        //one column or another depending on language
        val sqlQuery = "SELECT $columnName FROM informacion_medica WHERE $columnName LIKE '%$searchTerm%'"
        val myDB = openDatabase()
        val cursor = myDB.rawQuery(sqlQuery, null)
        val boolean = cursor!!.moveToFirst()
        if (cursor.count > 0) {
            do {
                var item = cursor.getString(cursor.getColumnIndex("$columnName"))
                suggestionsList.add(item)
            } while (cursor.moveToNext())

        }
        cursor.close()
        myDB.close()



        return suggestionsList

    }

    /*
     Get allergy items that match what the user entered in the search field
     */
    fun userSuggestionsAllergies(searchTerm: String, language: String): List<MutableList<String>> {
        val suggestionsList: MutableList<String> = ArrayList()
        val typeOfAllergyList: MutableList<String> = ArrayList()
        var columnName: String? = "Nombre_en" //default value
        var columnFamily: String? = "Familia_en"
        var familyName = "Allergies"
        var columnSubfamily = "Subfamilia_en"

        when (language) {
            "es" -> {
                //column with items in Spanish
                columnName = "Nombre_es"
                columnFamily = "Familia_es"
                familyName = "Alergias"
            }
            "en" -> {
                columnName = "Nombre_en"
                columnFamily = "Familia_en"
                familyName = "Allergies"
            }
        }

        val sqlQuery =
            "SELECT $columnName,$columnSubfamily FROM informacion_medica WHERE $columnFamily ='$familyName'AND $columnName LIKE '%$searchTerm%'"
        val myDB = openDatabase()
        val cursor = myDB.rawQuery(sqlQuery, null)
        val boolean = cursor!!.moveToFirst()
        if (cursor.count > 0) {
            do {
                var item = cursor.getString(cursor.getColumnIndex("$columnName"))
                var type = cursor.getString(cursor.getColumnIndex("$columnSubfamily"))
                typeOfAllergyList.add(type)
                suggestionsList.add(item)
            } while (cursor.moveToNext())

        }
        cursor.close()
        myDB.close()



        return listOf(typeOfAllergyList, suggestionsList)

    }

    /*
    Get other factors items that match what the user entered in the search field
     */
    fun factors(factors: String, language: String): MutableList<String> {
        val suggestionsList: MutableList<String> = ArrayList()
        var columnName: String? = "Nombre_en" //default value
        var columnFamily: String? = "Subfamilia_en"

        when (language) {
            "es" -> {
                columnName = "Nombre_es"
                columnFamily = "SubFamilia_es"
            }
            "en" -> {
                columnName = "Nombre_en"
                columnFamily = "Subfamilia_en"
            }
        }
        val sqlQuery = "SELECT $columnName FROM informacion_medica WHERE $columnFamily='$factors'"
        val myDB = openDatabase()
        val cursor = myDB.rawQuery(sqlQuery, null)
        val boolean = cursor!!.moveToFirst()
        if (cursor.count > 0) {
            do {
                var item = cursor.getString(cursor.getColumnIndex("$columnName"))
                suggestionsList.add(item)
            } while (cursor.moveToNext())

        }
        cursor.close()
        myDB.close()



        return suggestionsList


    }

    /*
    get allergy items depending on type of allergy
     */
    fun allergies(typeOfAllergy: String, language: String): MutableList<String> {
        val suggestionsList: MutableList<String> = ArrayList()
        var columnName: String? = "Nombre_en" //default value
        var columnFamily: String? = "Subfamilia_en"

        when (language) {
            "es" -> {
                columnName = "Nombre_es"
                columnFamily = "SubFamilia_es"
            }
            "en" -> {
                columnName = "Nombre_en"
                columnFamily = "Subfamilia_en"
            }
        }
        val sqlQuery = "SELECT $columnName FROM informacion_medica WHERE $columnFamily='$typeOfAllergy'"
        val myDB = openDatabase()
        val cursor = myDB.rawQuery(sqlQuery, null)
        val boolean = cursor!!.moveToFirst()
        if (cursor.count > 0) {
            do {
                var item = cursor.getString(cursor.getColumnIndex("$columnName"))
                suggestionsList.add(item)
            } while (cursor.moveToNext())

        }
        cursor.close()
        myDB.close()



        return suggestionsList


    }


}




