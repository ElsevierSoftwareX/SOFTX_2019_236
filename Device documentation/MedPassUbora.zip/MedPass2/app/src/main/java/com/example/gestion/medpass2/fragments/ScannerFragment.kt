package com.example.gestion.medpass2.fragments


import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.example.gestion.medpass2.other.Patient

import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.activities.MainActivity
import java.util.*


class ScannerFragment : BaseFragment() {

    var reader: readNFClistener? = null
    var mainActivity: MainActivity? = null

    override fun onAttach(context: Context?) {
        super.onAttach(context)

        try {
            reader = context as readNFClistener
            mainActivity = activity as MainActivity
        } catch (e: Exception) {
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val vista = inflater.inflate(R.layout.fragment_scanner, container, false)
        setTitle(getString(R.string.read_tag))
        return vista
    }

    override fun onStart() {
        super.onStart()
        reader!!.checkNFCEnabled()

    }


    fun retrieveData(msg: String) {
        translatedMessage(msg)

    }

    interface readNFClistener {
        fun showNFCSettings()
        fun checkNFCEnabled()
        fun sendData(msg: String)

    }

    //easier to do with GSON but it appears unordered so I developed a serialization method in Main Activity and now I must make a Patient object out of read string
    fun translatedMessage(message: String) {
        if (message == "") {
            Toast.makeText(context, "Cannot read that tag", Toast.LENGTH_LONG).show()
            var invitedPatient: Patient? = null
            mainActivity!!.saveInvitedPatient(invitedPatient)
        } else {
            var invitedPatient = Patient()
            var conditions: MutableList<String> = ArrayList()
            var foodAllergies: MutableList<String> = ArrayList()
            var otherAllergies: MutableList<String> = ArrayList()
            var drugsAllergies: MutableList<String> = ArrayList()
            var chronicMedication: MutableList<String> = ArrayList()
            var lastMedication: MutableList<String> = ArrayList()
            var factors: MutableList<String> = ArrayList()
            val language = Locale.getDefault().language
            var rawMessage = message.substringAfter("medpass://")
            val list = rawMessage.split(";")
            var listOfValues: MutableList<String> = ArrayList<String>()
            for (item in list) {
                var stringItem = item.trim()
                stringItem = stringItem.substringAfter(":").trim()
                listOfValues.add(stringItem)
            }
            //esta es la claveee
            conditions = listOfValues[10].replace("[", "").replace("]", "").split("\\s*,\\s*".toRegex()).toMutableList()
            drugsAllergies =
                listOfValues[11].replace("[", "").replace("]", "").trim().split("\\s*,\\s*".toRegex()).toMutableList()
            foodAllergies = listOfValues[12].replace("[", "").replace("]", "").trim().split("\\s*,\\s*".toRegex())
                .toMutableList()
            otherAllergies = listOfValues[13].replace("[", "").replace("]", "").trim().split("\\s*,\\s*".toRegex())
                .toMutableList()
            chronicMedication = listOfValues[14].replace("[", "").replace("]", "").trim().split("\\s*,\\s*".toRegex())
                .toMutableList()
            lastMedication = listOfValues[15].replace("[", "").replace("]", "").trim().split("\\s*,\\s*".toRegex())
                .toMutableList()
            factors = listOfValues[16].replace("[", "").replace("]", "").trim().split("\\s*,\\s*".toRegex())
                .toMutableList()
            if (conditions.size == 1 && conditions[0] == "") {
                conditions.clear()
            }
            if (drugsAllergies.size == 1 && drugsAllergies[0] == "") {
                drugsAllergies.clear()
            }
            if (foodAllergies.size == 1 && foodAllergies[0] == "") {
                foodAllergies.clear()
            }
            if (otherAllergies.size == 1 && otherAllergies[0] == "") {
                otherAllergies.clear()
            }
            if (chronicMedication.size == 1 && chronicMedication[0] == "") {
                chronicMedication.clear()
            }
            if (lastMedication.size == 1 && lastMedication[0] == "") {
                lastMedication.clear()
            }
            if (factors.size == 1 && factors[0] == "") {
                factors.clear()
            }
            Log.d("msg12345", conditions.toString())
            Log.d("cacatua111", listOfValues[7] + "caca" + listOfValues[8])
            invitedPatient = invitedPatient.copy(
                medPassID = listOfValues[0].trim(),
                date = listOfValues[1].trim(),
                name = listOfValues[2].trim(),
                surname = listOfValues[3].trim(),
                id = listOfValues[4].trim(),
                emergency = listOfValues[5].trim(),
                birth = listOfValues[6].trim(),
                nationality = listOfValues[7].trim(),
                insurance = listOfValues[8].trim(),
                bloodType = listOfValues[9].trim(),
                pathologies = conditions,
                drugsAllergies = drugsAllergies,
                foodAllergies = foodAllergies,
                otherAllergies = otherAllergies,
                chronicMedication = chronicMedication,
                lastMedication = lastMedication,
                factors = factors,
                additional = listOfValues[17]
            )
            mainActivity!!.saveInvitedPatient(invitedPatient)


        }
    }

    override fun onStop() {
        super.onStop()
        //once tag is read, set isScannerVisible to false in case the user wants to record tag.
        mainActivity!!.isScannerVisible = false
    }


}
