package com.example.gestion.medpass2.other

import android.R
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import com.example.gestion.medpass2.activities.MainActivity
import java.util.*

class CustomAutoCompleteListener (typeOfInfo:String,context: Context,adapter:ArrayAdapter<String>,autocomplete:AutoCompleteTextView) :TextWatcher{
    val info=typeOfInfo
    val context=context
    var adapter=adapter
    val autocomplete=autocomplete
    var typeOfAllergy:MutableList<String> = ArrayList()

    override fun afterTextChanged(s: Editable?) {

    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        customListeners(s.toString())

    }
    //change list of suggestions and autoCompletTextView adapter depending on what the user enters
    fun customListeners(userInput:String){
        val activity=context as MainActivity
        val language= Locale.getDefault().language
        when(info){

            "conditions"-> {
                val suggestions=activity!!.conditionsDB!!.userSuggestions(userInput.toString(),language)
                adapter.notifyDataSetChanged()
                adapter = ArrayAdapter(context, R.layout.simple_dropdown_item_1line,suggestions)
               autocomplete.setAdapter(adapter)

            }
            "medication"->{
                val suggestions=activity!!.medicationDatabase!!.userSuggestions(userInput.toString(),language)
                adapter.notifyDataSetChanged()
                adapter = ArrayAdapter(context, R.layout.simple_dropdown_item_1line,suggestions)
                autocomplete.setAdapter(adapter)

            }
            "allergies"->{
                val resultPat=activity!!.conditionsDB!!.userSuggestionsAllergies(userInput.toString(),language)
                val resultMed=activity!!.medicationDatabase!!.userSuggestions(userInput.toString(),language)
                val suggestions=resultPat[1]
                suggestions.addAll(resultMed)
                //Saves type of allergy to classify selected allergies in InvitedTagFragment
                typeOfAllergy=resultPat[0]
                adapter.notifyDataSetChanged()
                adapter = ArrayAdapter(context, R.layout.simple_dropdown_item_1line,suggestions)
                autocomplete.setAdapter(adapter)

            }
        }
    }

}