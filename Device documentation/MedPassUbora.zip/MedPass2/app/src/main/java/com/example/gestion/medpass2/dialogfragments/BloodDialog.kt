package com.example.gestion.medpass2.dialogfragments

import android.content.Context
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.Toast
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.activities.MainActivity

class BloodDialog : DialogFragment() {
    var mainActivity: MainActivity? = null
    var patient: Patient? = null
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity
        patient = mainActivity!!.retrievePatient()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val vista = inflater.inflate(R.layout.blood_dialog, container, false)
        //find views in the layout by ID. In this fragment extensions pluggin not used
        val save = vista.findViewById<Button>(R.id.save_blood)
        val blood_A = vista.findViewById<RadioButton>(R.id.blood_A)
        val blood_B = vista.findViewById<RadioButton>(R.id.blood_B)
        val blood_AB = vista.findViewById<RadioButton>(R.id.blood_AB)
        val blood_0 = vista.findViewById<RadioButton>(R.id.blood_0)
        val blood_positive = vista.findViewById<RadioButton>(R.id.blood_positive)
        val blood_negative = vista.findViewById<RadioButton>(R.id.blood_negative)
        val bloodButtons = listOf(blood_A, blood_B, blood_AB, blood_0, blood_positive, blood_negative)
        //display previous selections
        setSavedBloodType(patient, bloodButtons)
        //saves blood type selected by the user into patient and then saves it into shared preferences
        save.setOnClickListener {
            var blood_type: String = ""
            if (patient == null) {
                patient = Patient()
            }
            for (item in bloodButtons) {
                if (item.isChecked) {
                    blood_type += item.text.toString()
                    Log.d("log123456", blood_type)
                }
            }
            patient = patient!!.copy(bloodType = blood_type) //es la 1000 vez que fallo en esta mierda. ATENCIOOON
            this.mainActivity!!.savePatient(patient)
            Toast.makeText(context, getString(R.string.successful_save), Toast.LENGTH_LONG).show()
            dialog.dismiss() //close the dialog
        }
        return vista
    }

    // to display bloof type saved in patient by checking the correponding selectors

    fun setSavedBloodType(patient: Patient?, bloodButtons: List<RadioButton>) {
        if (patient != null) {
            if (patient.bloodType != "") {
                when (patient.bloodType) {
                    "A+" -> {
                        bloodButtons[0].isChecked = true
                        bloodButtons[4].isChecked = true
                    }
                    "A-" -> {
                        bloodButtons[0].isChecked = true
                        bloodButtons[5].isChecked = true
                    }
                    "B+" -> {
                        bloodButtons[1].isChecked = true
                        bloodButtons[4].isChecked = true
                    }
                    "B-" -> {
                        bloodButtons[1].isChecked = true
                        bloodButtons[5].isChecked = true
                    }
                    "AB+" -> {
                        bloodButtons[2].isChecked = true
                        bloodButtons[4].isChecked = true
                    }
                    "AB-" -> {
                        bloodButtons[2].isChecked = true
                        bloodButtons[5].isChecked = true
                    }
                    "0+" -> {
                        bloodButtons[3].isChecked = true
                        bloodButtons[4].isChecked = true
                    }
                    "0-" -> {
                        bloodButtons[3].isChecked = true
                        bloodButtons[5].isChecked = true
                    }
                    "A" -> bloodButtons[0].isChecked = true
                    "B" -> bloodButtons[1].isChecked = true
                    "AB" -> bloodButtons[2].isChecked = true
                    "0" -> bloodButtons[3].isChecked = true
                }

            }
        }

    }


}