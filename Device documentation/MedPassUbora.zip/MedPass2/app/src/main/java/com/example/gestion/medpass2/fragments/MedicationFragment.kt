package com.example.gestion.medpass2.fragments


import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.gestion.medpass2.other.CustomAutoCompleteListener
import com.example.gestion.medpass2.other.Patient

import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import com.example.gestion.medpass2.activities.MainActivity
import java.util.*


class MedicationFragment : BaseFragment() {
    //adapter for medication AutoCompleteTVs
    var medicationAdapter: ArrayAdapter<String>? = null
    //list for  most important groups of habitual drugs
    var chronicMedicationGeneral: MutableList<String> = ArrayList()
    //lists for chronic and recent medication
    var chronicMedication: MutableList<String> = ArrayList()
    var temporalMedication: MutableList<String> = ArrayList()
    //initial value for autoComplete adapter
    var initialValue = arrayOf("initial value")
    var mainActivity: MainActivity? = null
    var patient: Patient? = null
    var translatePatient: Patient? = null
    var language: String = ""
    var drugsGroups: List<String> = ArrayList()

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setTitle(getString(R.string.medication))
        val vista =
            inflater.inflate(R.layout.fragment_medication, container, false)   // Inflate the layout for this fragment
        language = Locale.getDefault().language
        patient = mainActivity!!.retrievePatient() //information in key
        translatePatient =
                Translation(context, patient).translateToLanguage(language) //translate patient's info to language
        //clean every list first
        chronicMedication.clear()
        chronicMedicationGeneral.clear()
        temporalMedication.clear()
        //find checkBoxes and AutoComplete views by id. In this case not using kotlin pluggin
        val thrombotic = vista.findViewById<CheckBox>(R.id.thrombotic_check)
        val arrhytmia = vista.findViewById<CheckBox>(R.id.arrhytmic_check)
        val diabetic = vista.findViewById<CheckBox>(R.id.diabetic_check)
        val epileptic = vista.findViewById<CheckBox>(R.id.epileptic_check)
        val hypertensive = vista.findViewById<CheckBox>(R.id.hypertensive_check)
        val parkinson = vista.findViewById<CheckBox>(R.id.parkinson_check)
        val chronicAuto = vista.findViewById<AutoCompleteTextView>(R.id.chronicMedicationAuto)
        val temporalAuto = vista.findViewById<AutoCompleteTextView>(R.id.temporalMedicationAuto)
        // list of groups of long term drugs from string resources
        drugsGroups = listOf(
            getString(R.string.antithrombotic), getString(R.string.antiarrhythmic), getString(R.string.antidiabetics),
            getString(R.string.antiepileptic), getString(R.string.antihypertensives), getString(R.string.antiparkinson)
        )
        //map creation with name of checkBox and checkBox, to be able to translate them
        val checkBoxes = mapOf<String, CheckBox>(
            drugsGroups[0] to thrombotic,
            drugsGroups[1] to arrhytmia,
            drugsGroups[2] to diabetic,
            drugsGroups[3] to epileptic,
            drugsGroups[4] to hypertensive,
            drugsGroups[5] to parkinson
        )
        //find medication layouts by id and save button
        val chronicLayout = vista.findViewById<LinearLayout>(R.id.addChronicMedication)
        val temporalLayout = vista.findViewById<LinearLayout>(R.id.addTemporalMedication)
        val save = vista.findViewById<Button>(R.id.medication_save)
        //creation and set of adapters and addition of text listeners to autoCompleteTV to change suggestions depending on what user enters
        medicationAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, initialValue)
        chronicAuto!!.addTextChangedListener(
            CustomAutoCompleteListener(
                "medication",
                context!!,
                medicationAdapter!!,
                chronicAuto
            )
        )
        temporalAuto!!.addTextChangedListener(
            CustomAutoCompleteListener(
                "medication",
                context!!,
                medicationAdapter!!,
                temporalAuto
            )
        )
        chronicAuto.setAdapter(medicationAdapter)
        temporalAuto.setAdapter(medicationAdapter)
        //display medication already added or updated
        displayMedicationSaved(checkBoxes, chronicLayout, temporalLayout, chronicMedication, temporalMedication)
        //configuration of on item click listener for both AutoCompTV
        chronicAuto!!.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            if (!chronicMedication.contains(selectedItem)) {
                chronicMedication.add(selectedItem.trim()) //selected item added to appropiate medication list
                createItem(selectedItem, chronicLayout, chronicMedication) //item added to layout
            }
            chronicAuto.setText("") //Clean AutoCompleteTV after item selected
            mainActivity?.hideKeyboard(context!! as Activity) //hide keyBoard to see element added

        }
        temporalAuto.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            if (!temporalMedication.contains(selectedItem.trim())) {
                temporalMedication.add(selectedItem)
                createItem(selectedItem, temporalLayout, temporalMedication)
            }
            temporalAuto.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)

        }
        // save medication changes into shared preferences using a translated patient
        save.setOnClickListener {
            if (patient == null) {
                patient = Patient()
            }
            chronicMedicationGeneral.clear()
            for (item in checkBoxes.values) {
                if (item.isChecked) {
                    chronicMedicationGeneral.add(item.text.toString()) //big group added into chronicMedication long list
                }
            }
            chronicMedicationGeneral.addAll(chronicMedication) //add the specific active principles, etc into the chronic list
            translatePatient = translatePatient!!.copy(
                chronicMedication = chronicMedicationGeneral,
                lastMedication = temporalMedication
            ) //copy the info into patient in the device language
            patient = Translation(context, translatePatient).translateToKey(language)//translate info to key
            mainActivity!!.savePatient(patient) //save into shared prefs
            Toast.makeText(context,getString(R.string.successful_save),Toast.LENGTH_LONG).show()

        }


        return vista
    }

    //displays items inside patient's medication attributes in medication layout
    fun displayMedicationSaved(
        checkBoxList: Map<String, CheckBox>,
        chronicLayout: LinearLayout,
        temporalLayout: LinearLayout,
        chronicList: MutableList<String>,
        temporalList: MutableList<String>
    ) {
        if (translatePatient == null) {

        } else {
            val groups = translatePatient?.chronicMedication!!
            val lastMedication = translatePatient?.lastMedication!!
            if (groups.isNotEmpty()) {
                for (item in groups) {
                    if (drugsGroups.contains(item)) {
                        var check = checkBoxList.getValue(item) //restore checkBox state
                        check.isChecked = true

                    } else {
                        createItem(item, chronicLayout, chronicList)
                        chronicMedication.add(item)
                    }
                }
            }
            if (lastMedication.isNotEmpty()) {
                for (item in lastMedication) {
                    createItem(item, temporalLayout, temporalList)
                    temporalMedication.add(item)
                }
            }
        }
    }

    //create medication items. TextView + remove button
    fun createItem(item: String, wrapLayout: LinearLayout, list: MutableList<String>) {
        val linearLayout = LinearLayout(context)
        linearLayout.orientation = LinearLayout.HORIZONTAL
        wrapLayout.addView(linearLayout)
        val layoutParams = linearLayout.layoutParams
        layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT
        layoutParams.width = LinearLayout.LayoutParams.MATCH_PARENT
        val textView = TextView(context)
        textView.text = item
        textView.setTextColor(Color.parseColor("#000000"))
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        val textParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
        //textParams.topMargin=10
        textView.layoutParams = textParams
        val button = ImageButton(context)
        val buttonParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.5f)
        button.layoutParams = buttonParams
        button.setImageResource(android.R.drawable.ic_delete)
        button.setBackgroundColor(Color.TRANSPARENT)
        button.setOnClickListener {
            list.remove(item)
            val viewgroup = button.parent as ViewGroup
            list.remove(item)
            viewgroup.removeAllViews()


        }
        linearLayout.addView(textView, textParams)
        linearLayout.addView(button, buttonParams)

    }


}
