package com.example.gestion.medpass2.fragments


import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import com.example.gestion.medpass2.activities.MainActivity
import kotlinx.android.synthetic.main.fragment_my_tag.*
import java.util.*


open class MyTagFragment : BaseFragment() {
    var mainActivity: MainActivity? = null
    var translatePatient: Patient? = null
    open var patient: Patient? = null
    var language: String = ""
    override fun onAttach(context: Context?) {
        super.onAttach(context)

        try {
            mainActivity = activity as MainActivity

        } catch (e: Exception) {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        setTitle(getString(R.string.my_tag))
        val vista = inflater.inflate(R.layout.fragment_my_tag, container, false)
        language = Locale.getDefault().language
        patient = mainActivity!!.retrievePatient() //key
        translatePatient = Translation(context, patient).translateToLanguage(language) //translated to language
        setHasOptionsMenu(true)
        return vista
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        displayPatientTag(translatePatient)
        createItemsList(translatePatient)

    }


    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater!!.inflate(R.menu.menu_mytag, menu)
        super.onCreateOptionsMenu(menu, inflater)

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.menu_recordTag -> {
                mainActivity?.checkNFCEnabled()
                Toast.makeText(context, getString(R.string.place_your_tag_next_to_the_phone), Toast.LENGTH_LONG).show()
                //record!!.recordTag(true)
                mainActivity?.recordTag = true
            }
            R.id.menu_help -> {
                val spannableStr = SpannableString(getString(R.string.help))
                val cyan = ForegroundColorSpan(Color.BLUE)
                spannableStr.setSpan(cyan, 0, spannableStr.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                val dialog = AlertDialog.Builder(context).create()
                dialog.setTitle(spannableStr)
                dialog.setMessage(getString(R.string.help_mytag))
                dialog.show()
            }
        }
        return true
    }

    //display filiation and blood type data
    open fun displayPatientTag(patient: Patient?) {
        if (patient == null) {
            tag_name.text = substringColor(resources.getString(R.string.name) + ":")
            tag_surname.text = substringColor(resources.getString(R.string.surname) + ":")
            tag_id.text = substringColor(resources.getString(R.string.id) + ":")
            tag_emergency.text = substringColor(resources.getString(R.string.emergencyC) + ":")
            tag_age.text = substringColor(resources.getString(R.string.age) + ":")
            tag_bloodType.text = substringColor(getString(R.string.bloodType) + ":")
            tag_nationality.text = substringColor(getString(R.string.nationality) + ":")
            tag_insurance.text = substringColor(getString(R.string.health_insurance) + ":")
        } else {
            tag_name.text = substringColor(resources.getString(R.string.name) + ":" + patient.name)
            tag_surname.text = substringColor(resources.getString(R.string.surname) + ":" + patient.surname)
            tag_id.text = substringColor(resources.getString(R.string.id) + ":" + patient.id)
            tag_emergency.text =
                substringColor(resources.getString(R.string.emergencyC) + ":" + patient.emergency)
            tag_age.text = substringColor(resources.getString(R.string.age) + ":" + patient.birth)
            tag_bloodType.text = substringColor(getString(R.string.bloodType) + ":" + patient.bloodType)
            tag_nationality.text = substringColor(getString(R.string.nationality) + ":" + patient.nationality)
            tag_insurance.text = substringColor(getString(R.string.health_insurance) + ":" + patient.insurance)
            tag_additional.text = patient.additional


        }
    }

    //to create dinamically textViews for pathologies etc add later medication
    fun createItemsList(patient: Patient?) {
        if (patient == null) {

        } else {
            val conditions = patient.pathologies
            val factors = patient.factors
            val drugsAllergies = patient.drugsAllergies
            val foodAllergies = patient.foodAllergies
            val otherAllergies = patient.otherAllergies
            val chronicMedication = patient.chronicMedication
            val lastMedication = patient.lastMedication
            if (conditions != null && conditions.isNotEmpty()) {
                addItemsToLayout(conditions, tag_layout_conditions)
            }
            if (factors != null && factors.isNotEmpty()) {
                addItemsToLayout(factors, tag_layout_otherFactors)
            }
            if (drugsAllergies != null) {
                if (drugsAllergies.isEmpty()) {
                    drugsAllergies.add(getString(R.string.no))
                }
                addItemsToLayout(drugsAllergies, tag_layout_drugsAllergies)
            }
            if (foodAllergies != null) {
                if (foodAllergies.isEmpty()) {
                    foodAllergies.add(getString(R.string.no))
                }
                addItemsToLayout(foodAllergies, tag_layout_foodAllergies)
            }

            if (otherAllergies != null) {
                if (otherAllergies.isEmpty()) {
                    otherAllergies.add(getString(R.string.no))
                }
                addItemsToLayout(otherAllergies, tag_layout_otherAllergies)
            }

            if (chronicMedication != null && chronicMedication.isNotEmpty()) {
                addItemsToLayout(chronicMedication, tag_layout_chronicMedication)
            }
            if (lastMedication != null && lastMedication.isNotEmpty()) {
                addItemsToLayout(lastMedication, tag_layout_lastMedication)
            }
        }


    }

    //add items as a list of textViews
    fun addItemsToLayout(list: MutableList<String>, layout: LinearLayout) {
        for (item in list) {
            val textV = TextView(context)
            textV.text = item
            textV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            textV.setTextColor(Color.parseColor("#000000"))
            textV.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            layout.addView(textV)
        }
    }

    //to write the label bold only
    fun substringColor(string: String): SpannableString {
        val spannableStr = SpannableString(string)
        val bold = StyleSpan(Typeface.BOLD)
        spannableStr.setSpan(bold, 0, spannableStr.indexOf(":") + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return spannableStr
    }


}
