package com.example.gestion.medpass2.fragments


import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.*
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.activities.MainActivity
import kotlinx.android.synthetic.main.fragment_profile.*

/*
This fragment corresponds to My Profile Screen

 */

class ProfileFragment : BaseFragment() {

    /*initialization of mainActivity variable
     and patient variable
    */

    var mainActivity: MainActivity? = null
    var patient: Patient? = null
    //to simulate insurance providers database
    var healthInsuranceList = listOf(
        "Adeslas" to "ES-Adeslas", "Mapfre" to "ES-Mapfre", "Sanitas"
                to "ES-Sanitas", "SERMAS" to "ES-SERMAS",
        "SAS" to "ES-SAS", "Aviva" to "UK-Aviva", "Vitality Health" to "UK-Vitality Health"
    )
    var nationalityList: List<Pair<String, String>>? = null
    /*
    In onAttach, an instance of MainActivity is saved into mainActivity variable
     */
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity
    }

    /*
    onCreateView():Toolbar title is set and patient is retrieved from shared preferences
     using mainActivity method retrievePatient(). It returns inflated view.
    */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        setTitle(getString(R.string.profile)) //Set toolbar title
        patient =
            mainActivity!!.retrievePatient() //get patient from sharedPreferences using MainActivity method retrievePatient()
        setHasOptionsMenu(true)//menu
        return inflater.inflate(R.layout.fragment_profile, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //setting phone format hint when emergencyContact_profile is focused
        emergencyContact_profile.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) emergencyContact_profile.hint = "+34 667554332" else emergencyContact_profile.hint = ""
        }
        //setting personal identification hint when field is focused
        id_profile.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) id_profile.hint = getString(R.string.id_numbers) else id_profile.hint = ""
        }
        //nationality adapter
        val nationalitySuggestions = ArrayList<String>()
        nationalityList = mainActivity?.nationalityList
        if (nationalityList != null) {
            for (pair in nationalityList!!) {
                nationalitySuggestions.add(pair.component1())
            }
        }
        val nationalityAdapter = ArrayAdapter(
            context!!, android.R.layout.simple_dropdown_item_1line,
            ArrayList<String>(nationalitySuggestions)
        )
        nationality_profile.setAdapter(nationalityAdapter)
        //take value from nationality selection
        nationality_profile.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position)
                .toString() //not item at 0 because it wouls only show the first element
            nationality_profile.setText(selectedItem)
        }
        //insurance adapter for dropdown selection
        val insuranceSuggestions = ArrayList<String>()
        for (pair in healthInsuranceList) {
            insuranceSuggestions.add(pair.component1())
        }
        val insuranceAdapter = ArrayAdapter(
            context!!, android.R.layout.simple_dropdown_item_1line,
            ArrayList<String>(insuranceSuggestions)
        )
        insurance_profile.setAdapter(insuranceAdapter)
        //take value selected from insurance dropdown
        insurance_profile.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position).toString()
            insurance_profile.setText(selectedItem)
        }
        /*
        On save_profile button Click, information is retrieved from fields and saved into a Patient. Then it is saved
        using sharedPreferences through savePatient method from MainActivity.
         */
        save_profile.setOnClickListener {
            //insurance to key and see if it matches allowed insurance
            var insuranceFlag = false
            var insurance = insurance_profile.text.toString()
            for (pair in healthInsuranceList) {
                if (pair.component1().equals(insurance)) {
                    insurance = pair.component2()
                    insuranceFlag = true
                    break
                }
            }
            if (!insuranceFlag) insurance_profile.setText("")

            //nationality to key and see if it matches allowed nationality
            var nationalityFlag = false
            var nationality = nationality_profile.text.toString()
            if (nationalityList != null) {
                for (pair in nationalityList!!) {
                    if (pair.component1().equals(nationality)) {
                        nationality = pair.component2()
                        nationalityFlag = true
                        break
                    }
                }
            }
            if (!nationalityFlag) nationality_profile.setText("")


            var flag = false
            /*
       Set error messages to warn user to fill mandatory fields
        */
            if (TextUtils.isEmpty(name_profile.text)) {
                name_profile.error = getString(R.string.first_name_required)
                flag = true
            } else {
                name_profile.error = null
            }
            if (TextUtils.isEmpty(surname_profile.text)) {
                surname_profile.error = getString(R.string.surname_required)
                flag = true
            } else {
                surname_profile.error = null
            }
            if (TextUtils.isEmpty(id_profile.text)) {
                id_profile.error = getString(R.string.id_required)
                flag = true
            } else {
                id_profile.error = null
            }
            if (TextUtils.isEmpty(emergencyContact_profile.text)) {
                emergencyContact_profile.error = getString(R.string.emergencyContact_required)
                flag = true
            } else {
                emergencyContact_profile.error = null
            }
            if (TextUtils.isEmpty(age_profile.text)) {
                age_profile.error = getString(R.string.age_required)
                flag = true
            } else {
                age_profile.error = null
            }
            if (TextUtils.isEmpty(nationality_profile.text)) {
                nationality_profile.error = getString(R.string.nationality_required)
                flag = true
            } else {
                nationality_profile.error = null
            }

            if (flag) {
                Toast.makeText(context, getString(R.string.no_save_mandatory), Toast.LENGTH_LONG).show()
            } else {

                if (patient == null) {
                    patient =
                        Patient() //if patient is null, creates a new Patient object
                }


                patient = patient!!.copy(
                    name = name_profile.text.toString().trim(),
                    surname = surname_profile.text.toString().trim(),
                    id = id_profile.text.toString().trim(),
                    emergency = emergencyContact_profile.text.toString().trim(),
                    birth = age_profile.text.toString().trim(), nationality = nationality, insurance = insurance
                )
                mainActivity!!.savePatient(patient)
                Toast.makeText(context, getString(R.string.successful_save), Toast.LENGTH_LONG).show()

            }

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater!!.inflate(R.menu.menu_profile, menu)
        super.onCreateOptionsMenu(menu, inflater)

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.menu_help -> {
                val spannableStr = SpannableString(getString(R.string.help))
                val cyan = ForegroundColorSpan(Color.BLUE)
                spannableStr.setSpan(cyan, 0, spannableStr.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                val dialog = AlertDialog.Builder(context).create()
                dialog.setTitle(spannableStr)
                dialog.setMessage(getString(R.string.help_profile))
                dialog.show()
            }
        }
        return true
    }


    /*
    Information previously entered and saved is displayed in the corresponding edit texts
     */
    override fun onStart() {
        super.onStart()
        setSavedProfileData(patient)

    }

    /*
    Takes a Patient as parameter and sets Edit Texts values using Patient's parameters if it is not null.
     */
    fun setSavedProfileData(patient: Patient?) {
        if (patient == null) {

        } else {
            //paso a clave
            var insuranceFlag = false
            var insurance = patient.insurance
            if (!insurance.isNullOrEmpty()) {
                for (pair in healthInsuranceList) {
                    if (pair.component2().equals(insurance)) {
                        insurance = pair.component1()
                        insuranceFlag = true
                        break
                    }
                }
            }

            var nationalityFlag = false
            var nationality = patient.nationality
            if (!nationality.isNullOrEmpty()) {
                for (pair in nationalityList!!) {
                    if (pair.component2().equals(nationality)) {
                        nationality = pair.component1()
                        nationalityFlag = true
                        break
                    }
                }
            }


            name_profile.setText(patient.name)
            surname_profile.setText(patient.surname)
            id_profile.setText(patient.id)
            emergencyContact_profile.setText(patient.emergency)
            age_profile.setText(patient.birth)
            nationality_profile.setText(nationality)
            insurance_profile.setText(insurance)
        }


    }


}
