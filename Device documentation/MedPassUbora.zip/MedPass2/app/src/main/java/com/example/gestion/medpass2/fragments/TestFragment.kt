package com.example.gestion.medpass2.fragments


import android.content.Context
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.util.Log
import android.view.*
import android.widget.*
import com.example.gestion.medpass2.other.ExpandableAdapter
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import com.example.gestion.medpass2.activities.MainActivity
import com.example.gestion.medpass2.dialogfragments.TestSearchDialog
import java.util.*


class TestFragment : BaseFragment() {
    var mainActivity: MainActivity? = null
    var patient: Patient? = null
    var translatePatient: Patient? = null
    var expandableAdapter: ExpandableAdapter? = null
    var language: String = ""
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        setTitle(getString(R.string.pathologies))
        language = Locale.getDefault().language
        val vista = inflater.inflate(R.layout.fragment_test, container, false)
        //expandable list header
        val header = resources.getStringArray(R.array.questionGroups)
        //get string arrays from string resources
        val circulatory = resources.getStringArray(R.array.circulatoryQ)
        val immune = resources.getStringArray(R.array.immuneQ)
        val digestive = resources.getStringArray(R.array.digestiveQ)
        val respiratory = resources.getStringArray(R.array.respiratoryQ)
        val endocrine = resources.getStringArray(R.array.endocrineQ)
        val nervous = resources.getStringArray(R.array.nervousQ)
        val infectious = resources.getStringArray(R.array.infectiousQ)
        val cancer = resources.getStringArray(R.array.cancerQ)
        val blood = resources.getStringArray(R.array.bloodQ)
        val urinary = resources.getStringArray(R.array.urinaryQ)
        //build body of expandable list
        val body =
            listOf(circulatory, blood, endocrine, infectious, immune, nervous, respiratory, digestive, urinary, cancer)
        val expandableListView = vista.findViewById<View>(R.id.expandableListView) as ExpandableListView
        displaySelectedPathologies()
        //set expandable list adapter using header and body
        expandableAdapter =
            ExpandableAdapter(context!!, expandableListView, header, body)
        expandableListView.setAdapter(expandableAdapter)
        setHasOptionsMenu(true)


        return vista
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater!!.inflate(R.menu.menu_test, menu)
        super.onCreateOptionsMenu(menu, inflater)

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.menu_searchAuto -> {
                saveTestInfoIntoPatient() //update patient's info right before opening search dialog
                showDialog(TestSearchDialog(), "TestSearchDialog")

            }
        }
        return true
    }

    override fun onPause() {
        super.onPause()
        saveTestInfoIntoPatient()
    }


    fun displaySelectedPathologies() {
        patient = mainActivity!!.retrievePatient()
        //translate to device language
        translatePatient = Translation(context, patient).translateToLanguage(language)
        val prefs = context!!.getSharedPreferences("ANSWERS", 0)
        val editor = prefs.edit()
        //clear preferences so that different language keys do not get mixed up
        editor.clear()
        editor.apply()
        if (translatePatient != null) {
            var conditions = translatePatient!!.pathologies!!
            val prefs2 = context!!.getSharedPreferences("ANSWERS", 0)
            val editor2 = prefs2.edit()
            //save patient's conditions into shared preferences so that expandable list view displays those items checked
            for (item in conditions) {
                editor2.putBoolean(item, true)
                editor2.apply()
                expandableAdapter?.notifyDataSetChanged()

            }


        }

    }

    //save test info into patient
    fun saveTestInfoIntoPatient() {
        patient = mainActivity!!.retrievePatient() //search field updates are in key
        if (patient == null) {
            patient = Patient()
        }
        //these keys are not from translating, are sharedpreferences info
        translatePatient = Translation(context, patient).translateToLanguage(language)
        var pathologies = translatePatient!!.pathologies
        val prefs = context!!.getSharedPreferences("ANSWERS", 0)
        val keyValue = prefs.all
        for (item in keyValue) {
            if (item.value as Boolean) {
                if (!pathologies!!.contains(item.key.trim())) {
                    pathologies!!.add(item.key.trim())
                }
            } else {
                if (pathologies!!.contains(item.key.trim())) {
                    pathologies!!.remove(item.key.trim())
                }

            }
            translatePatient = translatePatient!!.copy(pathologies = pathologies)
            //translate to key again
            patient = Translation(context, translatePatient).translateToKey(language)
            mainActivity!!.savePatient(patient)

        }
    }


    fun showDialog(dialog: DialogFragment, tag: String) {
        dialog.show(childFragmentManager, tag)
    }


}
