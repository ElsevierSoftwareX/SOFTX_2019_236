package com.example.gestion.medpass2.fragments


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.gestion.medpass2.R


open class BaseFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_base, container, false)
    }

    //set action bar title
    fun setTitle(title: String) {
        val activity = activity as AppCompatActivity
        val actionBar = activity.supportActionBar
        actionBar!!.title = title
    }


}
