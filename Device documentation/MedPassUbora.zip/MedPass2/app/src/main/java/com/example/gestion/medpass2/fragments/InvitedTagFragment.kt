package com.example.gestion.medpass2.fragments


import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.*
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.*
import android.widget.*
import com.example.gestion.medpass2.*
import com.example.gestion.medpass2.activities.MainActivity
import com.example.gestion.medpass2.other.CustomAutoCompleteListener
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.other.Translation
import kotlinx.android.synthetic.main.fragment_invited_tag.view.*
import java.util.*


class InvitedTagFragment : BaseFragment() {
    //adapters for AutoCompleteTextViews
    var insuranceAdapter: ArrayAdapter<String>? = null
    var conditionsAdapter: ArrayAdapter<String>? = null
    var medicationAdapter: ArrayAdapter<String>? = null
    var factorsAdapter: ArrayAdapter<String>? = null
    var allergiesAdapter: ArrayAdapter<String>? = null
    var initialValue = arrayOf("initial value")
    //autoCompleteTextViews
    var insuranceAuto: AutoCompleteTextView? = null
    var conditionsAuto: AutoCompleteTextView? = null
    var chronicAuto: AutoCompleteTextView? = null
    var lastAuto: AutoCompleteTextView? = null
    var factorsAuto: AutoCompleteTextView? = null
    var allergiesAuto: AutoCompleteTextView? = null
    //custom Listener for Allergies AutoCompleteTV
    var customListenerAllergies: CustomAutoCompleteListener? = null
    //lists for medical information
    var pathologies: MutableList<String> = ArrayList()
    var foodAllergies: MutableList<String> = ArrayList()
    var drugsAllergies: MutableList<String> = ArrayList()
    var otherAllergies: MutableList<String> = ArrayList()
    var lastMedication: MutableList<String> = ArrayList()
    var chronicMedication: MutableList<String> = ArrayList()
    var factors: MutableList<String> = ArrayList()
    //MainActivity object
    var mainActivity: MainActivity? = null
    //invitedPatient from Patient data class
    var invitedpatient: Patient? = null
    //blood and insurance editTexts
    var bloodType: EditText? = null
    var additional: EditText? = null
    //list of String with allowed blood types
    val possibleBloodType = listOf(
        "A+", "A-", "A", "B+", "B-", "B", "AB+",
        "AB-", "AB", "0+", "0-", "0"
    )
    val healthInsuranceList = listOf(
        "Adeslas" to "ES-Adeslas", "Mapfre" to "ES-Mapfre", "Sanitas"
                to "ES-Sanitas", "SERMAS" to "ES-SERMAS",
        "SAS" to "ES-SAS", "Aviva" to "UK-Aviva", "Vitality Health" to "UK-Vitality Health"
    )
    var nationalityList: List<Pair<String, String>>? = null
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setTitle(getString(R.string.invited_tag)) // set title of action bar
        val vista = inflater.inflate(R.layout.fragment_invited_tag, container, false) //inflate view of the fragment
        invitedpatient = mainActivity!!.retrieveInvitedPatient() //get patient read from invited tag
        val language = Locale.getDefault().language //detect device language config
        invitedpatient = Translation(
            context,
            invitedpatient
        ).translateToLanguage(language) //translate patient to device language

        //fill already created lists with invited patient's info
        pathologies = invitedpatient?.pathologies!!
        drugsAllergies = invitedpatient?.drugsAllergies!!
        foodAllergies = invitedpatient?.foodAllergies!!
        otherAllergies = invitedpatient?.otherAllergies!!
        chronicMedication = invitedpatient?.chronicMedication!!
        lastMedication = invitedpatient?.lastMedication!!
        factors = invitedpatient?.factors!!
        // find views by id
        bloodType = vista.findViewById(R.id.tag_bloodType)
        additional = vista.findViewById(R.id.inv_layout_additional)
        //find layouts by ID
        val conditionsLayout = vista.findViewById<LinearLayout>(R.id.inv_layout_conditions)
        val factorsLayout = vista.findViewById<LinearLayout>(R.id.inv_layout_otherFactors)
        val foodLayout = vista.findViewById<LinearLayout>(R.id.inv_layout_foodAllergies)
        val drugsLayout = vista.findViewById<LinearLayout>(R.id.inv_layout_drugsAllergies)
        val otherLayout = vista.findViewById<LinearLayout>(R.id.inv_layout_otherAllergies)
        val chronicLayout = vista.findViewById<LinearLayout>(R.id.inv_layout_chronicMedication)
        val lastLayout = vista.findViewById<LinearLayout>(R.id.inv_layout_lastMedication)
        //find AutoCompleteTextViews by id.
        conditionsAuto = vista.findViewById(R.id.inv_conditions_auto)
        chronicAuto = vista.findViewById(R.id.inv_chronic_auto)
        lastAuto = vista.findViewById(R.id.inv_last_auto)
        factorsAuto = vista.findViewById(R.id.inv_otherFactors_auto)
        allergiesAuto = vista.findViewById(R.id.inv_allergies_auto)
        insuranceAuto = vista.findViewById(R.id.inv_insurance_auto)
        //display info in the corresponding layout
        createItemsList(
            invitedpatient,
            context,
            conditionsLayout,
            factorsLayout,
            drugsLayout,
            foodLayout,
            otherLayout,
            chronicLayout,
            lastLayout
        )
        //display info already existing inside invited patient
        displayPatientTag(invitedpatient, vista, bloodType)
        //insurance suggestions
        val insuranceSuggestions = ArrayList<String>()
        for (pair in healthInsuranceList) {
            insuranceSuggestions.add(pair.component1())
        }
        //create ArrayAdapter for AutoCompleteTextViews
        insuranceAdapter = ArrayAdapter(
            context!!, android.R.layout.simple_dropdown_item_1line,
            ArrayList<String>(insuranceSuggestions)
        )
        conditionsAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, initialValue)
        medicationAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, initialValue)
        allergiesAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, initialValue)
        //Add custom listener for changing suggestions in conditions AutoComplete
        conditionsAuto!!.addTextChangedListener(
            CustomAutoCompleteListener(
                "conditions",
                context!!,
                conditionsAdapter!!,
                conditionsAuto!!
            )
        )
        //Add custom listener for changing suggestions in allergies AutoComplete
        customListenerAllergies =
            CustomAutoCompleteListener(
                "allergies",
                context!!,
                allergiesAdapter!!,
                allergiesAuto!!
            )
        allergiesAuto!!.addTextChangedListener(customListenerAllergies)
        //Add custom listener for changing suggestions in medication AutoCompleteTViews
        chronicAuto!!.addTextChangedListener(
            CustomAutoCompleteListener(
                "medication",
                context!!,
                medicationAdapter!!,
                chronicAuto!!
            )
        )
        lastAuto!!.addTextChangedListener(
            CustomAutoCompleteListener(
                "medication",
                context!!,
                medicationAdapter!!,
                lastAuto!!
            )
        )

        /*get factors from database directly (at the moment only 2 elements) as suggestions in factors auto,
        create factors adapter and set factors adapter
         */
        val factorsSuggestions =
            mainActivity!!.conditionsDB!!.factors(getString(R.string.presence_devices), Locale.getDefault().language)
        factorsAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, factorsSuggestions)
        //Set Adapters
        factorsAuto!!.setAdapter(factorsAdapter)
        conditionsAuto!!.setAdapter(conditionsAdapter)
        chronicAuto!!.setAdapter(medicationAdapter)
        lastAuto!!.setAdapter(medicationAdapter)
        allergiesAuto!!.setAdapter(allergiesAdapter)
        insuranceAuto!!.setAdapter(insuranceAdapter)

        /*
        set on item click listeners to all the autoComTVs.
         */
        insuranceAuto!!.setOnItemClickListener { parent, view, position, id ->
            val selectedItem =
                parent.getItemAtPosition(position).toString()//if I put 0 it always takes the first elemeny
            insuranceAuto?.setText(selectedItem)
        }
        conditionsAuto!!.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            if (invitedpatient == null) {
                invitedpatient = Patient()
            }
            val selectedItem = parent.getItemAtPosition(0).toString()
            if (!pathologies.contains(selectedItem)) {
                pathologies.add(selectedItem) //Add to pathologies list
                createItem(selectedItem, conditionsLayout, pathologies) //Add item to appropiate layout
            }
            conditionsAuto!!.setText("") //Erase content of AutoCompTV after selecting item
            mainActivity?.hideKeyboard(context!! as Activity) //hide keyboard to see item added

        }
        allergiesAuto!!.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            if (invitedpatient == null) {
                invitedpatient = Patient()
            }
            val selectedItem = parent.getItemAtPosition(0).toString()
            val typeInfo =
                customListenerAllergies!!.typeOfAllergy //when allergy selected, classified in appropiate type of Allergy
            if (position < typeInfo.size) {
                when (typeInfo[position]) {
                    "Food allergies" -> {
                        if (!foodAllergies.contains(selectedItem)) {
                            foodAllergies.add(selectedItem)
                            createItem(selectedItem, foodLayout, foodAllergies)
                        }
                    }
                    "Other allergies" -> {
                        if (!otherAllergies.contains(selectedItem)) {
                            otherAllergies.add(selectedItem)
                            createItem(selectedItem, otherLayout, otherAllergies)
                        }
                    }
                }
            } else {
                if (!drugsAllergies.contains(selectedItem)) {
                    drugsAllergies.add(selectedItem)
                    createItem(selectedItem, drugsLayout, drugsAllergies)
                }
            }
            allergiesAuto?.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)

        }


        chronicAuto!!.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            if (!chronicMedication.contains(selectedItem)) {
                chronicMedication.add(selectedItem)
                createItem(selectedItem, chronicLayout, chronicMedication)
            }
            chronicAuto!!.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)

        }
        lastAuto!!.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            if (!lastMedication.contains(selectedItem)) {
                lastMedication.add(selectedItem)
                createItem(selectedItem, lastLayout, lastMedication)
            }
            lastAuto!!.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)

        }
        factorsAuto!!.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            if (!factors.contains(selectedItem)) {
                factors.add(selectedItem)
                createItem(selectedItem, factorsLayout, factors)
            }
            factorsAuto!!.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)

        }

        /*validation of blood type editText. Only allowed blood types,
        spaces not allowed.
         */
        bloodType?.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val entry = s?.toString()
                if (s != null) {
                    if (s.length > 0) {
                        if (s.toString().contains(" ")) {
                            bloodType?.error = "Space is not allowed"
                            bloodType?.setText("")
                        } else {
                            bloodType?.error =
                                if (possibleBloodType.contains(s.toString().toUpperCase())) null else "Wrong blood type"

                        }

                    }
                }

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s.toString() == " ") {
                    bloodType?.error = getString(R.string.space_not_allowed)
                    bloodType?.setText("")
                }

            }
        })
        //when focus lost from blood edit Text, if blood type entered is not allowed, edit Text cleaned.
        bloodType?.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (!possibleBloodType.contains(bloodType?.text.toString().toUpperCase()))
                    bloodType?.setText("")
            }


        }





        setHasOptionsMenu(true)



        return vista
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater!!.inflate(R.menu.menu_mytag, menu)
        super.onCreateOptionsMenu(menu, inflater)

    }

    /*when record item from menu selected, info saved into invited Patient and into sharedPreferences,
    recordInvitedTag flag from MainActivity set to true-> can record invited tag
       */
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.menu_recordTag -> {
                invitedpatient = invitedpatient!!.copy(
                    pathologies = pathologies,
                    bloodType = bloodType!!.text.toString().toUpperCase(),
                    insurance = insuranceAuto!!.text.toString(),
                    chronicMedication = chronicMedication,
                    lastMedication = lastMedication,
                    additional = additional?.text.toString()
                )
                mainActivity!!.saveInvitedPatient(invitedpatient)
                Toast.makeText(context, getString(R.string.place_your_tag_next_to_the_phone), Toast.LENGTH_LONG).show()
                mainActivity!!.recordInvitedTag = true
            }
            R.id.menu_help -> {
                val spannableStr = SpannableString(getString(R.string.help))
                val cyan = ForegroundColorSpan(Color.BLUE)
                spannableStr.setSpan(cyan, 0, spannableStr.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                val dialog = AlertDialog.Builder(context).create()
                dialog.setTitle(spannableStr)
                dialog.setMessage(getString(R.string.help_invitedtag))
                dialog.show()
            }
        }
        return true
    }


    //set textViews and editTexts text from info inside invitedPatient
    fun displayPatientTag(patient: Patient?, vista: View, bloodType: EditText?) {
        if (patient == null) {

        } else {
            //esto no lo va a poder modificar el medico
            vista.tag_medPassID.text = substringColor("MedPassID:" + patient.medPassID)
            vista.tag_date.text = substringColor(getString(R.string.date) + ":" + patient.date)
            vista.tag_name.text = substringColor(resources.getString(R.string.name) + ":" + patient.name)
            vista.tag_surname.text = substringColor(resources.getString(R.string.surname) + ":" + patient.surname)
            vista.tag_id.text = substringColor(resources.getString(R.string.id) + ":" + patient.id)
            vista.tag_emergency.text =
                substringColor(resources.getString(R.string.emergencyC) + ":" + patient.emergency)
            vista.tag_age.text = substringColor(resources.getString(R.string.age) + ":" + patient.birth)
            vista.tag_nationality.text = substringColor(getString(R.string.nationality) + ":" + patient.nationality)
            bloodType?.setText(patient.bloodType)
            insuranceAuto?.setText(patient.insurance)
            vista.inv_layout_additional.setText(patient.additional)


        }
    }

    //fill medical layouts with items inside invitedPatient.
    fun createItemsList(
        patient: Patient?,
        context: Context?,
        conditionsLayout: LinearLayout,
        factorsLayout: LinearLayout,
        drugsAllergiesLayout: LinearLayout,
        foodAllergiesLayout: LinearLayout,
        otherAllergiesLayout: LinearLayout,
        chronicLayout: LinearLayout,
        lastLayout: LinearLayout
    ) {
        if (patient == null) {

        } else {
            if (patient.pathologies == null || patient.pathologies.isEmpty()) {
            } else {
                val pathologies = patient.pathologies
                for (item in pathologies) {
                    createItem(item, conditionsLayout, this.pathologies)
                }

            }
            if (patient.factors == null || patient.factors.isEmpty()) {
            } else {
                val factors = patient.factors
                for (item in factors) {
                    createItem(item, factorsLayout, this.factors)
                }
            }
            if (patient.drugsAllergies == null) {
            } else {
                val drugs = patient.drugsAllergies
                for (item in drugs) {
                    createItem(item, drugsAllergiesLayout, this.drugsAllergies)

                }
            }

            if (patient.foodAllergies == null) {
            } else {
                val food = patient.foodAllergies
                for (item in food) {
                    createItem(item, foodAllergiesLayout, this.foodAllergies)
                }
            }

            if (patient.otherAllergies == null) {
            } else {
                val other = patient.otherAllergies
                for (item in other) {
                    createItem(item, otherAllergiesLayout, this.otherAllergies)
                }
            }

            if (patient.chronicMedication == null || patient.chronicMedication.isEmpty()) {
            } else {
                val chronic = patient.chronicMedication
                for (item in chronicMedication) {
                    createItem(item, chronicLayout, chronicMedication)
                }
            }
            if (patient.lastMedication == null || patient.lastMedication.isEmpty()) {
            } else {
                val last = patient.lastMedication
                for (item in last) {
                    createItem(item, lastLayout, lastMedication)
                }
            }
        }


    }


//each item displayed inside layout consists of a textView and a remove button

    fun createItem(item: String, wrapLayout: LinearLayout, list: MutableList<String>) {
        val linearLayout = LinearLayout(context)
        linearLayout.orientation = LinearLayout.HORIZONTAL
        wrapLayout.addView(linearLayout)
        val layoutParams = linearLayout.layoutParams
        layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT
        layoutParams.width = LinearLayout.LayoutParams.MATCH_PARENT
        val textView = TextView(context)
        textView.text = item
        textView.setTextColor(Color.parseColor("#000000"))
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        val textParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
        textParams.topMargin = 10
        textParams.bottomMargin = 10
        textParams.gravity = Gravity.CENTER
        textView.layoutParams = textParams
        val button = ImageButton(context)
        val buttonParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.5f)
        buttonParams.topMargin = 10
        buttonParams.bottomMargin = 10
        buttonParams.gravity = Gravity.CENTER
        button.layoutParams = buttonParams
        button.setImageResource(android.R.drawable.ic_delete)
        button.setBackgroundColor(Color.TRANSPARENT)
        //if button is clicked, item erased from layout
        button.setOnClickListener {
            list.remove(item)
            val viewgroup = button.parent as ViewGroup
            list.remove(item)
            viewgroup.removeAllViews()


        }
        linearLayout.addView(textView, textParams)
        linearLayout.addView(button, buttonParams)

    }

    //part of string with bold style
    fun substringColor(string: String): SpannableString {
        val spannableStr = SpannableString(string)
        val bold = StyleSpan(Typeface.BOLD)
        spannableStr.setSpan(bold, 0, spannableStr.indexOf(":") + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return spannableStr
    }


}
