package com.example.gestion.medpass2.activities

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.support.design.widget.NavigationView
import android.support.v4.app.Fragment
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import com.example.gestion.medpass2.databases.conditionsDB
import com.example.gestion.medpass2.other.NFCTools
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import com.example.gestion.medpass2.databases.MedicationDB
import com.example.gestion.medpass2.dialogfragments.TestSearchDialog
import com.example.gestion.medpass2.fragments.*
import com.google.gson.Gson
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), ScannerFragment.readNFClistener, TestSearchDialog.notifyChange {


    var isScannerVisible = false
    var recordTag = false
    var recordInvitedTag = false
    var nfcAdapter: NfcAdapter? = null
    var drawerLayout: DrawerLayout? = null
    var conditionsDB: conditionsDB? = null
    var medicationDatabase: MedicationDB? = null
    var navigationView: NavigationView? = null
    var patient: Patient? = null
    var language: String? = "en"
    //in future versions this will be replaced by a complete database with health systems and health insurance providers
    var healthInsuranceList: List<Pair<String, String>>? = null
    //in following versions, this will be replaced with spinner or similar with flags and country codes to standarize nationality entry. This is a proof of concept
    var nationalityList: List<Pair<String, String>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        patient = retrievePatient()
        //at the moment it is just a list, in the future a database with more health providers
        healthInsuranceList = listOf(
            "Adeslas" to "ES-Adeslas", "Mapfre" to "ES-Mapfre", "Sanitas"
                    to "ES-Sanitas", "SERMAS" to "ES-SERMAS",
            "SAS" to "ES-SAS", "Aviva" to "UK-Aviva", "Vitality Health" to "UK-Vitality Health"
        )
        //at the moment just some examples. Add more.
        nationalityList = listOf(
            getString(R.string.spanish) to "ES",
            getString(R.string.british) to "GB",
            getString(R.string.kenyan) to "KE",
            getString(R.string.italian) to "IT",
            getString(R.string.swede) to "Swede"
        )
        //set nfc adapter
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)?.let { it }
        navigationView = this.findViewById(R.id.navigationDrawer)
        val toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        supportActionBar!!.setHomeAsUpIndicator(R.drawable.ic_navigation)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        language = Locale.getDefault().language
//lateral menu on item selected displays corresponding fragment
        navigationView!!.setNavigationItemSelectedListener { item ->
            var flag = false
            var fragment: Fragment? = null
            var TAG: String? = null
            isScannerVisible = false
            when (item.itemId) {
                R.id.menu_profile -> {
                    fragment = ProfileFragment()
                    TAG = "ProfileFragment"
                    flag = true
                    isScannerVisible = false

                }
                R.id.menu_myTag -> {
                    fragment = MyTagFragment()
                    TAG = "MyTagFragment"
                    flag = true
                    isScannerVisible = false

                }
                R.id.menu_medicalInfo -> {

                    fragment = MedicalInfoFragment()
                    TAG = "MedicalInfoFragment"
                    flag = true
                    isScannerVisible = false

                }

                R.id.menu_scanner -> {

                    fragment = ScannerFragment()
                    TAG = "ScannerFragment"
                    flag = true
                    isScannerVisible = false

                }
            }
            if (flag) {
                seeSelectedFragment(fragment!!, TAG!!, item)
                isScannerVisible = if (item == navigationView!!.menu.getItem(3)) true else false
                drawerLayout = findViewById(R.id.drawer_layout)
                drawerLayout!!.closeDrawers()

            }
            true


        }


    }


    //to create and show selected fragment
    fun seeSelectedFragment(fragment: Fragment?, TAG: String?, item: MenuItem?) {
        if (fragment != null && TAG != null) {
            hideKeyboard(this)
            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            if (supportFragmentManager.findFragmentByTag(TAG) == null) {
                fragmentTransaction.replace(R.id.content_frame, fragment, TAG).addToBackStack(TAG)
            } else {
                val fragmentByTag = fragmentManager.findFragmentByTag(TAG)
                fragmentTransaction.replace(R.id.content_frame, fragmentByTag!!)
            }
            fragmentTransaction.commit()
            fragmentManager.executePendingTransactions()
            if (item == null) {

            } else {
                item.isChecked = true
            }

        }
    }

    override fun onStart() {
        super.onStart()
        //instalation of all the databases
        conditionsDB = conditionsDB(this)
        conditionsDB!!.installDataBaseIfNotExists()
        medicationDatabase = MedicationDB(this)
        medicationDatabase!!.installDataBaseIfNotExists()
        //in case nfc tag is detected when app is closed and intent triggers app opening
        val intent = this.intent
        if (NfcAdapter.ACTION_NDEF_DISCOVERED == intent.action) {
            //nfc trigger
            seeSelectedFragment(ScannerFragment(), "ScannerFragment", navigationView!!.menu.getItem(3))
            //retrieve data from tag
            readATag(intent)
        } else {
            //first scren seen when opening the app manually
            seeSelectedFragment(MedicalInfoFragment(), "MedicalInfoFragment", navigationView!!.menu.getItem(2))
        }


    }

    override fun onResume() {
        super.onResume()
        //enable foreground dispatch
        NFCTools.enableNFCInForeground(nfcAdapter!!, this, MainActivity::class.java)


    }



    /*
    this method manages NFC intents. If recordTag is true, it writes patient into tag.
    If not, it reads from tag.
    If recordInvitedTag is true, it records invitedPatient into tag.
     */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (recordTag) {
            patient = retrievePatient()
            val boolean =
                checkPatientForIDGeneration(patient)//if mandatory fields are not empty and have the right length
            if (boolean) {
                var successful = NFCTools.createNFCMessage(serialize(patient), intent!!)
                if (successful) {
                    Toast.makeText(this, getString(R.string.message_successfully), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.cannot_write), Toast.LENGTH_LONG).show()
                }

            } else {
                Toast.makeText(this, getString(R.string.complete_mandatory), Toast.LENGTH_LONG).show()

            }
            //set recordTag flag to false
            recordTag = false
        } else if (recordInvitedTag) {
            checkNFCEnabled()
            var invited = retrieveInvitedPatient()
            invited = Translation(this, invited).translateToKey(language!!)!!
            var successful = NFCTools.createNFCMessage(serialize(invited), intent!!)
            if (successful) {
                Toast.makeText(this, getString(R.string.message_successfully), Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, getString(R.string.cannot_write), Toast.LENGTH_LONG).show()
            }
            recordInvitedTag = false

        } else {
            //read tag
            if (!isScannerVisible) {
                isScannerVisible = true
                seeSelectedFragment(ScannerFragment(), "ScannerFragment", navigationView!!.menu.getItem(3))
            }
            readATag(intent)
        }


    }

    /*
    reads message from tag and sends it to scanner Fragment in which message is converted into an invited patient.
     */
    fun readATag(intent: Intent?) {
        val readMedPass = NFCTools.receiveMessageFromDevice(intent!!)
        sendData(readMedPass)
        if (retrieveInvitedPatient() == null) {

        } else {
            //if the patient read fom tag is the same as the patient object from the owner of the app, Mi Tag is opened.
            //if it is not the same->Invited Tag
            var invited = retrieveInvitedPatient() //retrieve invited patient saved by Scanner Fragment
            var original = retrievePatient()
            if (checkPatientForIDGeneration(invited) and checkPatientForIDGeneration(original)) {
                if (generateId(invited!!) == (generateId(original!!))) {
                    savePatient(invited)
                    seeSelectedFragment(MyTagFragment(), "MyTagFragment", null)
                } else {
                    seeSelectedFragment(InvitedTag(), "InvitedTag", null)
                }
            } else {
                seeSelectedFragment(InvitedTag(), "InvitedTag", null)
                isScannerVisible = false

            }
        }

    }


    override fun onPause() {
        super.onPause()
        //disable foregroun dispatch

        NFCTools.disableNFCInForeground(nfcAdapter!!, this)

    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            android.R.id.home -> {
                drawerLayout = findViewById(R.id.drawer_layout)
                drawerLayout!!.openDrawer(GravityCompat.START)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    //if NFC is not active, it takes the user to settings
    override fun showNFCSettings() {
        Toast.makeText(this, R.string.enableNFC, Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_NFC_SETTINGS))

    }

    //sends data read from tag to Scanner Fragment

    override fun sendData(msg: String) {
        val fragment = supportFragmentManager.findFragmentByTag("ScannerFragment") as ScannerFragment
        fragment.retrieveData(msg)
    }

    //check if NFC is enabled or not. If it is not enabled->settings
    override fun checkNFCEnabled() {
        if (!(nfcAdapter!!.isEnabled)) {
            showNFCSettings()
        }
    }

    /*
    saves patient in share preferences. To convert patient into string->Gson. It may be changed to the serialization method used to write
    into the tag.
     */

    fun savePatient(patient: Patient?) {
        val prefs = getPreferences(Context.MODE_PRIVATE)
        val savedData = prefs.edit()
        if (patient == null) {
            savedData.putString("Patient", "empty")
            savedData.apply()
        } else {
            val gson = Gson().toJson(patient)
            savedData.putString("Patient", gson)
            savedData.apply()
        }
    }

    /*
    same method but for invited patient.
     */
    fun saveInvitedPatient(patient: Patient?) {
        val prefs = getPreferences(Context.MODE_PRIVATE)
        val savedData = prefs.edit()
        if (patient == null) {
            savedData.putString("InvitedPatient", "empty")
            savedData.apply()
        } else {
            val gson = Gson().toJson(patient)
            savedData.putString("InvitedPatient", gson)
            savedData.apply()
        }
    }

    /*
    gets the saved patient from preferences and converts it to Patient() using Gson.
     It may be changed to the deserialization method used to read
     the tag.

     */
    fun retrievePatient(): Patient? {
        val prefs = getPreferences(Context.MODE_PRIVATE)
        val json = prefs.getString("Patient", "")
        Log.d("log123456", json)
        if (json == "" || json == "empty") {
            return null
        } else {
            return Gson().fromJson(json, Patient::class.java)
        }

    }

    //same method but for invited patient
    fun retrieveInvitedPatient(): Patient? {
        val prefs = getPreferences(Context.MODE_PRIVATE)
        val json = prefs.getString("InvitedPatient", "")
        Log.d("log123456", json)
        if (json == "" || json == "empty") {
            return null
        } else {
            return Gson().fromJson(json, Patient::class.java)
        }

    }

    // when disease added or removed in test search dialog, notify to expandable list adapter from Test Fragment
    override fun notifyChanges() {
        val fragment = supportFragmentManager.findFragmentByTag("TestFragment") as TestFragment
        fragment.displaySelectedPathologies()

    }

    //check if MedPassID can be generated
    fun checkPatientForIDGeneration(patient: Patient?): Boolean {
        if (patient != null) {
            if (patient.name.isNullOrEmpty() || patient.surname.isNullOrEmpty() || patient.id.isNullOrEmpty() || patient.name.length < 2 ||
                patient.surname.length < 2 || patient.id.length < 3
            ) {
                return false
            }

            return true
        }

        return false
    }

    //provisional method for generating MedPassID. Just an example.
    fun generateId(patient: Patient): String {
        val name = patient.name!!
        val surname = patient.surname!!
        val id = patient.id!!
        var medPassId = ""
        var name0 = name[0].toInt()
        var name1 = name[1].toInt()
        var surname0 = surname[0].toInt()
        var surname1 = surname[0].toInt()
        medPassId = name0.toString() + name1.toString() + id.subSequence(
            id.length - 3,
            id.length - 1
        ) + surname0.toString() + surname1.toString()
        return medPassId

    }

    //serialize patient to write NFC tag
    fun serialize(patient: Patient?): String {
        if (patient == null) {
            return ""
        } else {
            //
            val serialization =
                "medPassID:" + generateId(patient) + ";" + "date:" + getDate() + ";" + "name:" + patient.name + ";" + "surname:" + patient.surname + ";" + "id:" + patient.id +
                        ";" + "emergency:" + patient.emergency + ";" + "birth:" + patient.birth + ";" + "nationality:" + patient.nationality + ";" + "healthInsurance:" + patient.insurance + ";" + "bloodType:" + patient.bloodType + ";" + "pathologies:" + patient.pathologies?.toString()?.trim() +
                        ";" + "drugsAllergies:" + patient.drugsAllergies?.toString()?.trim() + ";" + "foodAllergies:" + patient.foodAllergies?.toString()?.trim() + ";" + "otherAllergies:" + patient.otherAllergies?.toString()?.trim() +
                        ";" + "chronicMedication:" + patient.chronicMedication?.toString()?.trim() + ";" + "lastMedication:" + patient.lastMedication?.toString()?.trim() + ";" + "otherFactors:" + patient.factors + ";" + "additional:" + patient.additional
            return serialization
        }
    }

    fun getDate(): String {
        var date = Calendar.getInstance().getTime();
        var formatter = SimpleDateFormat("yyyy-MM-dd")
        return formatter.format(date)


    }

    //hide keyboard
    fun hideKeyboard(activity: Activity?) {
        if (activity != null) {
            val imm = activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
            var view = activity.currentFocus
            //If no view currently has focus, create a new one, just so we can grab a window token from it
            if (view == null) {
                view = View(activity)
            }
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }

    }


}
