package com.example.gestion.medpass2.fragments


import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.text.InputFilter
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.*
import android.widget.*
import com.example.gestion.medpass2.other.Patient

import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.activities.MainActivity

import com.example.gestion.medpass2.dialogfragments.BloodDialog
import com.example.gestion.medpass2.dialogfragments.FactorsDialog
import android.widget.LinearLayout


class MedicalInfoFragment : BaseFragment() {

    var mainActivity: MainActivity? = null
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        try {
            mainActivity = activity as MainActivity
        } catch (e: Exception) {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        setTitle(getString(R.string.medical_info))
        val vista = inflater.inflate(R.layout.fragment_medical_info, container, false)
        val conditions = vista.findViewById<RelativeLayout>(R.id.conditions) as View
        val blood = vista.findViewById<RelativeLayout>(R.id.blood) as View
        val factors = vista.findViewById<RelativeLayout>(R.id.factors) as View
        val medication = vista.findViewById<View>(R.id.medication)
        val allergies = vista.findViewById<View>(R.id.allergies)
        setHasOptionsMenu(true)
        //on conditions button click, mainActivity changes fragment to TestFragment
        conditions.setOnClickListener {
            mainActivity?.seeSelectedFragment(TestFragment(), "TestFragment", null)
        }

        blood.setOnClickListener {
            showDialog(BloodDialog(), "BloodDialog")

        }

        factors.setOnClickListener {
            showDialog(FactorsDialog(), "FactorsDialog")
        }
        //on conditions button click, mainActivity changes fragment to MedicationFragment
        medication.setOnClickListener {
            mainActivity?.seeSelectedFragment(MedicationFragment(), "MedicationFragment", null)
        }
        //on conditions button click, mainActivity changes fragment to AllergiesFragment
        allergies.setOnClickListener {
            mainActivity?.seeSelectedFragment(AllergiesFragment(), "AllergiesFragment", null)

        }


        return vista
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater!!.inflate(R.menu.menu_medical_info, menu)
        super.onCreateOptionsMenu(menu, inflater)

    }

    /*when additional is clicked, custom alert dialog created. Trying to do it programmatically instead of
    using a layout*/
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.menu_help -> {
                val spannableStr = SpannableString(getString(R.string.help))
                val cyan = ForegroundColorSpan(Color.BLUE)
                spannableStr.setSpan(cyan, 0, spannableStr.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                val dialog = AlertDialog.Builder(context).create()
                dialog.setTitle(spannableStr)
                dialog.setMessage(getString(R.string.help_medicalInfo))
                dialog.show()
            }
            R.id.menu_additional -> {
                var patient = mainActivity!!.retrievePatient()
                if (patient == null) {
                    patient = Patient()

                }
                var button = Button(context)
                val linearLayout = LinearLayout(context)
                linearLayout.orientation = LinearLayout.VERTICAL
                button.setBackgroundResource(R.drawable.roundedbutton)
                button.text = getString(R.string.save)
                button.setTextColor(Color.WHITE)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = 0
                lp.marginStart = 20
                lp.marginEnd = 20
                lp.bottomMargin = 20
                val editText = EditText(context)
                editText.setText(patient?.additional)
                var inputFilter = arrayOfNulls<InputFilter>(1)
                inputFilter[0] = InputFilter.LengthFilter(50) //setting a fixed additional info size
                editText.filters = inputFilter
                val dialog = AlertDialog.Builder(context).create()
                dialog.setTitle(getString(R.string.additional))
                dialog.setMessage(getString(R.string.comment_health_status))
                button.setOnClickListener {
                    //not allowed characters which make serialization fail
                    var text = editText.text.toString().replace(":", "").replace(";", "")
                    patient = patient?.copy(additional = text)
                    mainActivity!!.savePatient(patient)
                    Toast.makeText(context, getString(R.string.successful_save), Toast.LENGTH_LONG).show()
                    dialog.dismiss()
                }
                linearLayout.addView(editText, lp)
                linearLayout.addView(button, lp)
                dialog.setView(linearLayout)
                dialog.show()


            }
        }
        return true
    }

    fun showDialog(dialog: DialogFragment, tag: String) {
        dialog.show(childFragmentManager, tag)
    }


}
