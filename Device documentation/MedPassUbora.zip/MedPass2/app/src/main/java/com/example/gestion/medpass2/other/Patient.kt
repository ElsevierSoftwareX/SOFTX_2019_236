package com.example.gestion.medpass2.other

import java.io.Serializable
 //data class which contains the user's info
 data class Patient(
    val medPassID:String?,
    val date:String?,
    val name:String?,
    val surname:String?,
    val id:String?,
    val emergency:String?,
    val birth:String?,
    val nationality:String?,
    val insurance:String?,
    val bloodType:String?,
    val pathologies:MutableList<String>?,
    val drugsAllergies:MutableList<String>?,
    val foodAllergies:MutableList<String>?,
    val otherAllergies:MutableList<String>?,
    val chronicMedication:MutableList<String>?,
    val lastMedication:MutableList<String>?,
    val factors:MutableList<String>?,
    val additional:String?):Serializable{
    constructor() : this(
       "",
       "",
       "",
       "",
       "",
       "",
       "",
       "",
       "",
       "",
       mutableListOf<String>(),
       mutableListOf<String>(),
       mutableListOf<String>(),
       mutableListOf<String>(),
       mutableListOf<String>(),
       mutableListOf<String>(),
       mutableListOf<String>(),
       ""
    )
 }



