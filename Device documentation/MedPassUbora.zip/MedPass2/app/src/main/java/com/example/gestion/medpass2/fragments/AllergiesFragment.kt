package com.example.gestion.medpass2.fragments


import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.gestion.medpass2.other.CustomAutoCompleteListener
import com.example.gestion.medpass2.other.Patient

import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import com.example.gestion.medpass2.activities.MainActivity
import kotlinx.android.synthetic.main.fragment_allergies.*
import java.util.*


class AllergiesFragment : BaseFragment() {
    //Initialization of adapters for autoCompleteTextViews for drug allergies, food Allergies and other Allergies
    var foodAdapter: ArrayAdapter<String>? = null
    var drugsAdapter: ArrayAdapter<String>? = null
    var otherAdapter: ArrayAdapter<String>? = null
    //Initialization of mutableLists for selected allergies
    val foodAllergies: MutableList<String> = ArrayList()
    val drugsAllergies: MutableList<String> = ArrayList()
    val otherAllergies: MutableList<String> = ArrayList()
    // initial Value for autoComplete suggestions when retrieved from database
    var initialValue = arrayOf("initial value")
    //Initialization of MainActivity object
    var mainActivity: MainActivity? = null
    //Initialization of patient and translated patient, two objects of Patient()
    var patient: Patient? = null
    var translatePatient: Patient? = null
    //Language string init
    var language: String = ""

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setTitle(getString(R.string.allergies))//set toolbar title
        val vista =
            inflater.inflate(R.layout.fragment_allergies, container, false) // Inflate the layout for this fragment
        //clean allergies list
        foodAllergies.clear()
        drugsAllergies.clear()
        otherAllergies.clear()
        language = Locale.getDefault().language
        //make suggestions lists for food and other allergies. Done this way because at the moment lists are short enough
        val foodSuggestions = mainActivity!!.conditionsDB!!.allergies(getString(R.string.food_allergies), language)
        val otherSuggestions = mainActivity!!.conditionsDB!!.allergies(getString(R.string.other_allergies), language)
        //create ArrayAdapters using context, and list of suggestions. drugsAdapter created with initial value
        foodAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, foodSuggestions)
        drugsAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, initialValue)
        otherAdapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, otherSuggestions)
        /*get Patient from sharedPreferences through MainActivity method.
        This patient was saved using keys, so needs to be translated to device language
        */
        patient = mainActivity!!.retrievePatient()
        //create a new patient were info is translated to device language
        translatePatient = Translation(context, patient).translateToLanguage(language)
        return vista
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //set adapters to autoCompleteTextViews
        foodAllergies_auto.setAdapter(foodAdapter)
        drugsAllergies_auto.addTextChangedListener( //TextChangeListener to change list of suggestions depending on what user introduced
            CustomAutoCompleteListener(
                "medication",
                context!!,
                drugsAdapter!!,
                drugsAllergies_auto
            )
        )
        drugsAllergies_auto.setAdapter(drugsAdapter)
        otherAllergies_auto.setAdapter(otherAdapter)
        // set Click listeners to checkBoxes using onCheckClicked method
        food_check.setOnClickListener {
            onCheckClicked(food_check, foodAllergies_auto, foodAllergies, foodSelections)
        }
        drugs_check.setOnClickListener {
            onCheckClicked(drugs_check, drugsAllergies_auto, drugsAllergies, drugsSelections)
        }
        other_check.setOnClickListener {
            onCheckClicked(other_check, otherAllergies_auto, otherAllergies, otherSelections)
        }
        /*on Item clicked from suggestions list, if it was not added before to the
        appropriate allergies list, is now added. After item click, autoComplete test is
        set to "" and keyBoard is hidden so that element added can be seen
        */

        foodAllergies_auto.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            foodAllergies_auto.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)
            if (!foodAllergies.contains(selectedItem)) {
                createItem(selectedItem, foodSelections, foodAllergies)
                foodAllergies.add(selectedItem)

            }
        }
        otherAllergies_auto.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            otherAllergies_auto.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)
            if (!otherAllergies.contains(selectedItem)) {
                createItem(selectedItem, otherSelections, otherAllergies)
                otherAllergies.add(selectedItem)
            }

        }
        drugsAllergies_auto.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            drugsAllergies_auto.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)
            if (!drugsAllergies.contains(selectedItem)) {
                createItem(selectedItem, drugsSelections, drugsAllergies)
                drugsAllergies.add(selectedItem)

            }
        }
/*
save drugs, food and other allergies into translated patient and translates it again to key
before saving it into sharedPreferences
 */
        save_allergies.setOnClickListener {
            if (patient == null) {

            } else {
                translatePatient = translatePatient!!.copy(
                    drugsAllergies = drugsAllergies,
                    foodAllergies = foodAllergies,
                    otherAllergies = otherAllergies
                )
                patient = Translation(context, translatePatient).translateToKey(language)
                mainActivity!!.savePatient(patient)
                Toast.makeText(context,getString(R.string.successful_save),Toast.LENGTH_LONG).show()

            }
        }
    }

    //display data already saved by user
    override fun onStart() {
        super.onStart()
        displayItemsSelected(
            translatePatient,
            listOf(drugs_check, food_check, other_check),
            drugsSelections,
            foodSelections,
            otherSelections
        )
    }

    /*if checkBox is checked, the search field (autoComplete) becomes focusable
     if is not checked, autoCom not focusable, list of allergies cleaned and items removed.
     */

    fun onCheckClicked(check: CheckBox, auto: AutoCompleteTextView, list: MutableList<String>, layout: LinearLayout) {
        if (check.isChecked) auto.isFocusableInTouchMode = true
        else {
            auto.isFocusableInTouchMode = false
            list.clear()
            removeItem(layout)


        }
    }

    //set all the checkBoxes to unCheck
    override fun onPause() {
        super.onPause()
        for (item in listOf(other_check, food_check, drugs_check)) {
            item.isChecked = false
        }
    }

    /*create list of selected items below "Allergies selections". Each item
    has a button to remove it.
       */
    fun createItem(item: String, wrapLayout: LinearLayout, list: MutableList<String>) {
        val linearLayout = LinearLayout(context)
        linearLayout.orientation = LinearLayout.HORIZONTAL
        wrapLayout.addView(linearLayout)
        val layoutParams = linearLayout.layoutParams
        layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT
        layoutParams.width = LinearLayout.LayoutParams.MATCH_PARENT
        val textView = TextView(context)
        textView.text = item
        textView.setTextColor(Color.parseColor("#000000"))
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        val textParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        textParams.topMargin = 10
        textView.layoutParams = textParams
        val button = ImageButton(context)
        val buttonParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        button.layoutParams = buttonParams
        button.setImageResource(android.R.drawable.ic_delete)
        button.setBackgroundColor(Color.TRANSPARENT)
        button.setOnClickListener {
            list.remove(item)
            val viewgroup = button.parent as ViewGroup
            list.remove(item)
            viewgroup.removeAllViews()


        }
        linearLayout.addView(textView, textParams)
        linearLayout.addView(button, buttonParams)

    }

    //removes all items of a certain type of allergy
    fun removeItem(wrapLayout: LinearLayout) {
        wrapLayout.removeAllViews()
    }

    //displays patient's allergies already saved by the user or updated from tag.
    fun displayItemsSelected(
        patient: Patient?,
        check: List<CheckBox>,
        drugsLayout: LinearLayout,
        foodLayout: LinearLayout,
        otherLayout: LinearLayout
    ) {
        if (patient == null) {

        } else {
            val drugs = patient.drugsAllergies
            val food = patient.foodAllergies
            val other = patient.otherAllergies
            if (drugs!!.isNotEmpty()) {
                check[0].performClick()
                for (item in drugs) {
                    drugsAllergies.add(item)
                    createItem(item, drugsLayout, drugsAllergies)
                }
            }
            if (food!!.isNotEmpty()) {
                check[1].performClick()
                for (item in food) {
                    foodAllergies.add(item)
                    createItem(item, foodLayout, foodAllergies)
                }
            }
            if (other!!.isNotEmpty()) {
                check[2].performClick()
                for (item in other) {
                    otherAllergies.add(item)
                    createItem(item, otherLayout, otherAllergies)
                }
            }


        }


    }
}


