package com.example.gestion.medpass2.other

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import java.io.IOException
import java.lang.RuntimeException

/*
I used this webpage to add NFC o the project
https://android.jlelse.eu/writing-to-a-nfc-tag-on-android-8d58f5e3c1fc
https://android.jlelse.eu/reading-from-a-nfc-tag-fdc254d6bf5c
 */

object NFCTools {
    fun createNFCMessage(payload: String, intent: Intent?): Boolean {
        val uri = "medpass://" + payload
        val record = NdefRecord.createUri(uri.trim())
        val nfcMessage = NdefMessage(arrayOf(record))
        intent?.let {
            val tag = it.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
            return writeMessageToTag(nfcMessage, tag)
        }
        return false

    }

    fun writeMessageToTag(nfcMessage: NdefMessage, tag: Tag?): Boolean {

        try {
            val nDefTag = Ndef.get(tag)

            nDefTag?.let {
                it.connect()
                if (it.maxSize < nfcMessage.toByteArray().size) {
                    //message is too big
                    return false
                }
                if (it.isWritable) {
                    //overwrites NdefMessage into the tag. Tag already contains a Ndef message so is already formatted
                    it.writeNdefMessage(nfcMessage)
                    it.close()
                    //message successfully writen into tag
                    return true
                } else {

                    return false
                }
            }
// get instance of NdefFormatable. If it is null, Ndef format is not supported
            val nDefFormatableTag = NdefFormatable.get(tag)

            nDefFormatableTag?.let {
                try {
                    //if tag is formatable, write message in Ndef format
                    it.connect()
                    it.format(nfcMessage)
                    it.close()
                    //The data is written to the tag
                    return true
                } catch (e: IOException) {
                    //Failed to format tag
                    return false
                }
            }
            //NDEF is not supported
            return false

        } catch (e: Exception) {
            //Write operation has failed
        }
        return false
    }

    //
    fun receiveMessageFromDevice(intent: Intent): String {
        var mensajeRecibido: String = ""
        val action = intent.action
        if (NfcAdapter.ACTION_NDEF_DISCOVERED == action) {
            val parcelables = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
            val nDefMessages = (parcelables.map { it as NdefMessage }).toTypedArray()
            nDefMessages[0].records?.let {
                it.forEach {
                    it?.payload.let {
                        it?.let {
                            //mensajeRecibido += String(it).trim()
                            return String(it)
                        }
                    }
                }

            }

            //return mensajeRecibido
        } else {
            return mensajeRecibido

        }
        return mensajeRecibido
    }


    fun <T> enableNFCInForeground(nfcAdapter: NfcAdapter, activity: Activity, classType: Class<T>) {
        val pendingIntent = PendingIntent.getActivity(
            activity, 0,
            Intent(activity, classType).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0
        )
        val nfcIntentFilter = IntentFilter()

        val filters = arrayOf(nfcIntentFilter)
        with(filters[0]) {
            this.addAction(NfcAdapter.ACTION_NDEF_DISCOVERED)
            this.addCategory(Intent.CATEGORY_DEFAULT)
            try {
                this.addDataScheme("medpass")
            } catch (ex: IntentFilter.MalformedMimeTypeException) {
                throw RuntimeException("Check your MIME type")
            }
        }

        val TechLists = arrayOf(arrayOf(Ndef::class.java.name), arrayOf(NdefFormatable::class.java.name))

        nfcAdapter.enableForegroundDispatch(activity, pendingIntent, filters, TechLists)
    }

    fun disableNFCInForeground(nfcAdapter: NfcAdapter, activity: Activity) {
        nfcAdapter.disableForegroundDispatch(activity)
    }
}


