package com.example.gestion.medpass2.dialogfragments

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.gestion.medpass2.other.CustomAutoCompleteListener
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import com.example.gestion.medpass2.activities.MainActivity
import java.util.*

class TestSearchDialog : DialogFragment() {

    var mainActivity: MainActivity? = null
    var patient: Patient? = null
    var translatePatient: Patient? = null
    var adapter: ArrayAdapter<String>? = null
    var pathologies: MutableList<String> = ArrayList()
    var notify: notifyChange? = null
    var initialValue = arrayOf("initial value")
    var language: String = ""
    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mainActivity = activity as MainActivity
        try {
            notify = context as notifyChange
        } catch (e: Exception) {

        }

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val vista = inflater.inflate(R.layout.testsearch_dialog, container, false)
        language = Locale.getDefault().language
        pathologies.clear()
        patient = mainActivity!!.retrievePatient() //esta en clave
        if (patient == null) {
            patient = Patient()
        }
        translatePatient = Translation(context, patient).translateToLanguage(language)
        pathologies = translatePatient?.pathologies!!
        val searchAuto = vista.findViewById<AutoCompleteTextView>(R.id.searchTestAuto)
        val searchLayout = vista.findViewById<LinearLayout>(R.id.testSearchadditional)
        val save = vista.findViewById<Button>(R.id.save_testSearch)
        adapter = ArrayAdapter(context!!, android.R.layout.simple_dropdown_item_1line, initialValue)
        //change suggestions list depending on what the user enters
        searchAuto.addTextChangedListener(
            CustomAutoCompleteListener(
                "conditions",
                context!!,
                adapter!!,
                searchAuto
            )
        )
        searchAuto.setAdapter(adapter)
        //to get the selected item and display it below
        searchAuto.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(0).toString()
            if (!pathologies!!.contains(selectedItem)) {
                pathologies!!.add(selectedItem)
                createItem(selectedItem, searchLayout, pathologies)
            }
            searchAuto!!.setText("")
            mainActivity?.hideKeyboard(context!! as Activity)

        }
        save.setOnClickListener {
            translatePatient =
                translatePatient!!.copy(pathologies = pathologies) //Esta en la lengua, hay que pasarlo a key
            patient = Translation(context, translatePatient).translateToKey(language)
            mainActivity!!.savePatient(patient)
            Log.d("nosequepasa", patient.toString())
            //to notify expandable list adapter that data may have changed
            notify?.notifyChanges()
            Toast.makeText(context, getString(R.string.successful_save), Toast.LENGTH_LONG).show()
            dialog.dismiss()
        }
        displayConditionsSaved(searchLayout)
        return vista
    }

    fun displayConditionsSaved(searchLayout: LinearLayout) {
        if (translatePatient != null) {
            var conditions = translatePatient?.pathologies!!
            for (item in conditions) {
                createItem(item, searchLayout, pathologies)
            }

        }
    }

    //Displays diseases with a text and a cross button in order to be able to remove it
    fun createItem(item: String, wrapLayout: LinearLayout, list: MutableList<String>) {
        val linearLayout = LinearLayout(context)
        linearLayout.orientation = LinearLayout.HORIZONTAL
        wrapLayout.addView(linearLayout)
        val layoutParams = linearLayout.layoutParams
        layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT
        layoutParams.width = LinearLayout.LayoutParams.MATCH_PARENT
        val textView = TextView(context)
        textView.text = item
        textView.setTextColor(Color.parseColor("#000000"))
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        val textParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
        textParams.topMargin = 10
        textView.layoutParams = textParams
        val button = ImageButton(context)
        val buttonParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.5f)
        button.layoutParams = buttonParams
        button.setImageResource(android.R.drawable.ic_delete)
        button.setBackgroundColor(Color.TRANSPARENT)
        button.setOnClickListener {
            list.remove(item)
            val viewgroup = button.parent as ViewGroup
            list.remove(item)
            viewgroup.removeAllViews()


        }
        linearLayout.addView(textView, textParams)
        linearLayout.addView(button, buttonParams)

    }
//to notify pathologies changes to expandable list adapter
    interface notifyChange {
        fun notifyChanges()
    }


}