package com.example.gestion.medpass2.fragments


import android.os.Bundle
import android.view.*
import com.example.gestion.medpass2.other.Patient
import com.example.gestion.medpass2.R
import com.example.gestion.medpass2.other.Translation
import kotlinx.android.synthetic.main.fragment_invited_tag_noeditable.*
import java.util.*

/*this class extends MyTagFragment as it has nearly the same information and methods
but used when invited tag is read
 */
class InvitedTag : MyTagFragment() {
    var invitedPatient: Patient? = null
    var translateInvitedPatient: Patient? = null
    var healthInsurance: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setTitle(getString(R.string.invited_tag))
        val vista = inflater.inflate(R.layout.fragment_invited_tag_noeditable, container, false)
        language = Locale.getDefault().language
        invitedPatient = mainActivity!!.retrieveInvitedPatient() //This patient contains info read from tag in key
        healthInsurance = invitedPatient?.insurance
        translateInvitedPatient = Translation(
            context,
            invitedPatient
        ).translateToLanguage(language) //translate patient's info into device language
        setHasOptionsMenu(true)
        return vista

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        displayPatientTag(translateInvitedPatient)
        createItemsList(translateInvitedPatient)
    }

    override fun displayPatientTag(patient: Patient?) {
        super.displayPatientTag(patient)
        if (patient != null) {
            tag_insurance.text = substringColor(getString(R.string.health_insurance) + ":" + healthInsurance)
            tag_medPassID.text = substringColor("MedPassID:" + patient.medPassID)
            tag_date.text = substringColor(getString(R.string.date) + ":" + patient.date)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater!!.inflate(R.menu.menu_edit, menu)

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.menu_edit -> {
                mainActivity?.seeSelectedFragment(InvitedTagFragment(), "InvitedTagFragment", null)
            }
        }
        return true
    }


}
