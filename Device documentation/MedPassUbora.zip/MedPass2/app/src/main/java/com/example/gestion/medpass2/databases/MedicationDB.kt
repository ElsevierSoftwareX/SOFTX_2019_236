package com.example.gestion.medpass2.databases

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.io.FileOutputStream
import java.lang.RuntimeException

open class MedicationDB(context: Context) : SQLiteOpenHelper(
    context,
    DB_NAME, null,
    DB_VERSION
) {
    val context = context
    override fun onCreate(db: SQLiteDatabase?) {

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }

    companion object {
        const val DB_NAME = "drugs.sqlite3"
        const val DB_VERSION = 1

    }

    /*
    This method checks if database is already copied and if it is not,
    it copies it from assets.
     */
    fun installDataBaseIfNotExists() {
        val inputStream = context.assets.open(DB_NAME)
        try {
            val outputFile = File(context.getDatabasePath(DB_NAME).path)
            if (!outputFile.exists()) {
                val outPutStream = FileOutputStream(outputFile)

                inputStream.copyTo(outPutStream)
                inputStream.close()
                outPutStream.flush()
                outPutStream.close()
            }
        } catch (exception: Throwable) {
            throw RuntimeException("couldn't install database")
        }

    }

    fun openDatabase(): SQLiteDatabase {
        return SQLiteDatabase.openDatabase(context.getDatabasePath(DB_NAME).path, null, 0)
    }

    /*
    This fun is used to make queries to database in order to get items that match what the user entered in the search field
     */
    fun userSuggestions(searchTerm: String, language: String): MutableList<String> {
        val suggestionsList: MutableList<String> = ArrayList()
        var columnName: String? = "drug_en" //default value
// depending on the language, it looks at one column or another
        when (language) {
            "es" -> {
                columnName = "drug_es"
            }
            "en" -> {
                columnName = "drug_en"
            }
        }
        val sqlQuery = "SELECT $columnName FROM drugs WHERE $columnName LIKE '$searchTerm%'"
        val myDB = openDatabase()
        val cursor = myDB.rawQuery(sqlQuery, null)
        val boolean = cursor!!.moveToFirst()
        if (cursor.count > 0) {
            do {
                var item = cursor.getString(cursor.getColumnIndex("$columnName"))
                suggestionsList.add(item)
            } while (cursor.moveToNext())

        }
        cursor.close()
        myDB.close()



        return suggestionsList

    }


}